import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env';
import { errorMiddleware } from './middleware/error.middleware';
import { globalLimiter } from './middleware/rateLimit.middleware';
import authRoutes from './modules/auth/auth.routes';

const app = express();

// Security headers — always first
app.use(helmet());

// CORS — only allow frontend origin
app.use(
  cors({
    origin: env.ALLOWED_ORIGINS.split(',').map((o) => o.trim()),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  })
);

// Body parsing — limit size to prevent payload attacks
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

// Logging
if (env.NODE_ENV !== 'test') {
  app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// Global rate limit
app.use(globalLimiter);

// Health check — used by Railway/Vercel
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', env: env.NODE_ENV });
});

// ─── Routes ───────────────────────────────────────────────
app.use('/api/auth', authRoutes);
// Phase 5+:
// app.use('/api/listings', listingRoutes);
// app.use('/api/users', userRoutes);
// app.use('/api/reviews', reviewRoutes);
// app.use('/api/verification', verificationRoutes);
// app.use('/api/admin', adminRoutes);
// app.use('/api/reports', reportRoutes);
// ──────────────────────────────────────────────────────────

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'NOT_FOUND' });
});

// Global error handler — must be last
app.use(errorMiddleware);

const start = async () => {
  try {
    // Connect Redis
    const { redis } = await import('./config/redis');
    await redis.connect();

    app.listen(env.PORT, () => {
      console.log(`🚀 LetBy API running on port ${env.PORT} [${env.NODE_ENV}]`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
};

start();

export default app;
