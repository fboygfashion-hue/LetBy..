import { prisma } from '../../config/prisma';
import { signToken } from '../../utils/jwt';
import { verifyTelegramInitData } from '../../utils/telegram.verify';
import { AppError } from '../../middleware/error.middleware';
import { cache } from '../../config/redis';
import type { TelegramAuthInput, UpgradeToSellerInput } from './auth.validator';

const SESSION_TTL = 60 * 60 * 24 * 7; // 7 days

export const authService = {
  /**
   * Verifies Telegram initData, upserts user, returns JWT.
   * Called every time the Mini App opens — must be fast.
   */
  async telegramAuth(input: TelegramAuthInput) {
    const { user: tgUser } = verifyTelegramInitData(input.initData);

    // Upsert user — create on first visit, update profile on return
    const user = await prisma.user.upsert({
      where: { telegramId: String(tgUser.id) },
      create: {
        telegramId: String(tgUser.id),
        telegramUsername: tgUser.username ?? null,
        firstName: tgUser.first_name,
        lastName: tgUser.last_name ?? null,
        photoUrl: tgUser.photo_url ?? null,
      },
      update: {
        telegramUsername: tgUser.username ?? null,
        firstName: tgUser.first_name,
        lastName: tgUser.last_name ?? null,
        photoUrl: tgUser.photo_url ?? null,
      },
      select: {
        id: true,
        telegramId: true,
        role: true,
        isActive: true,
        sellerProfile: {
          select: { isVerified: true, shopName: true },
        },
      },
    });

    if (!user.isActive) {
      throw new AppError('Account suspended', 403, 'ACCOUNT_SUSPENDED');
    }

    const token = signToken({
      userId: user.id,
      telegramId: user.telegramId,
      role: user.role,
    });

    // Cache user session for fast middleware lookups
    await cache.set(
      `session:${user.id}`,
      { userId: user.id, role: user.role },
      SESSION_TTL
    );

    return {
      token,
      user: {
        id: user.id,
        telegramId: user.telegramId,
        firstName: tgUser.first_name,
        lastName: tgUser.last_name,
        username: tgUser.username,
        photoUrl: tgUser.photo_url,
        role: user.role,
        sellerProfile: user.sellerProfile ?? null,
      },
    };
  },

  /**
   * Upgrades a BUYER to SELLER role.
   * Creates SellerProfile. Verification happens separately.
   */
  async upgradeToSeller(userId: string, input: UpgradeToSellerInput) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, role: true, sellerProfile: true },
    });

    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    if (user.sellerProfile) {
      throw new AppError('Already a seller', 409, 'ALREADY_SELLER');
    }

    // Transaction: upgrade role + create seller profile atomically
    const updated = await prisma.$transaction(async (tx) => {
      const updatedUser = await tx.user.update({
        where: { id: userId },
        data: { role: 'SELLER' },
        select: { id: true, telegramId: true, role: true },
      });

      await tx.sellerProfile.create({
        data: {
          userId,
          shopName: input.shopName,
          shopDescription: input.shopDescription ?? null,
        },
      });

      return updatedUser;
    });

    // Reissue token with updated role
    const token = signToken({
      userId: updated.id,
      telegramId: updated.telegramId,
      role: updated.role,
    });

    // Invalidate old session cache
    await cache.del(`session:${userId}`);
    await cache.set(
      `session:${userId}`,
      { userId: updated.id, role: updated.role },
      SESSION_TTL
    );

    return { token, role: updated.role };
  },

  /**
   * Returns the current authenticated user's profile.
   */
  async getMe(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        telegramId: true,
        telegramUsername: true,
        firstName: true,
        lastName: true,
        photoUrl: true,
        role: true,
        createdAt: true,
        sellerProfile: {
          select: {
            shopName: true,
            shopDescription: true,
            shopBanner: true,
            isVerified: true,
            verifiedAt: true,
            totalSales: true,
            avgResponseMin: true,
            scamReports: true,
          },
        },
        verificationReq: {
          select: { status: true, submittedAt: true },
        },
      },
    });

    if (!user) throw new AppError('User not found', 404, 'NOT_FOUND');
    return user;
  },

  /**
   * Soft logout — removes session cache.
   * JWT is stateless so client must discard the token.
   */
  async logout(userId: string) {
    await cache.del(`session:${userId}`);
  },
};
