import { Request, Response, NextFunction } from 'express';
import { authService } from './auth.service';

export const authController = {
  async telegramAuth(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await authService.telegramAuth(req.body);
      res.status(200).json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  async upgradeToSeller(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await authService.upgradeToSeller(req.user!.userId, req.body);
      res.status(200).json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  async getMe(req: Request, res: Response, next: NextFunction) {
    try {
      const user = await authService.getMe(req.user!.userId);
      res.status(200).json({ success: true, data: user });
    } catch (err) {
      next(err);
    }
  },

  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      await authService.logout(req.user!.userId);
      res.status(200).json({ success: true, message: 'Logged out' });
    } catch (err) {
      next(err);
    }
  },
};
