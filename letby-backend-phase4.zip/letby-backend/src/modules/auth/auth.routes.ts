import { Router } from 'express';
import { authController } from './auth.controller';
import { authenticate } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { authLimiter } from '../../middleware/rateLimit.middleware';
import { telegramAuthSchema, upgradeToSellerSchema } from './auth.validator';

const router = Router();

// POST /api/auth/telegram — verify initData, return JWT
router.post(
  '/telegram',
  authLimiter,
  validate(telegramAuthSchema),
  authController.telegramAuth
);

// GET /api/auth/me — get current user profile
router.get('/me', authenticate, authController.getMe);

// POST /api/auth/upgrade — buyer becomes seller
router.post(
  '/upgrade',
  authenticate,
  validate(upgradeToSellerSchema),
  authController.upgradeToSeller
);

// POST /api/auth/logout — clear session cache
router.post('/logout', authenticate, authController.logout);

export default router;
