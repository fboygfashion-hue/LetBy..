import { z } from 'zod';

export const telegramAuthSchema = z.object({
  initData: z.string().min(1, 'initData is required'),
});

export const upgradeToSellerSchema = z.object({
  shopName: z
    .string()
    .min(3, 'Shop name must be at least 3 characters')
    .max(60, 'Shop name too long'),
  shopDescription: z.string().max(500).optional(),
});

export type TelegramAuthInput = z.infer<typeof telegramAuthSchema>;
export type UpgradeToSellerInput = z.infer<typeof upgradeToSellerSchema>;
