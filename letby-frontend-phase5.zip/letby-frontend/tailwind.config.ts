/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // LetBy Brand — trusted, modern, Ethiopian market
        brand: {
          DEFAULT: '#0D7A5F',  // deep teal — trust
          light:   '#10957A',
          dark:    '#085C47',
          muted:   '#E8F5F1',
        },
        accent: {
          DEFAULT: '#F59E0B',  // amber — action, CTA
          light:   '#FEF3C7',
          dark:    '#B45309',
        },
        verified: {
          DEFAULT: '#059669',
          bg:      '#ECFDF5',
          text:    '#065F46',
        },
        risk: {
          low:    '#059669',
          medium: '#D97706',
          high:   '#DC2626',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          raised:  '#F8FAFB',
          muted:   '#F1F5F4',
        },
        ink: {
          DEFAULT: '#0F1F1C',
          secondary: '#4A6360',
          muted:     '#8FA8A4',
          inverse:   '#FFFFFF',
        },
      },
      fontFamily: {
        // DM Sans — clean, modern, great on mobile
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
        // Syne — distinctive for headings/brand
        display: ['"Syne"', 'system-ui', 'sans-serif'],
        mono: ['"DM Mono"', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        card:   '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
        'card-hover': '0 4px 12px rgba(13,122,95,0.12)',
        modal:  '0 20px 60px rgba(0,0,0,0.15)',
      },
      animation: {
        'fade-up':    'fadeUp 0.3s ease-out',
        'fade-in':    'fadeIn 0.2s ease-out',
        'slide-up':   'slideUp 0.35s cubic-bezier(0.32,0.72,0,1)',
        'pulse-soft': 'pulseSoft 1.5s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          '0%':   { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%':   { transform: 'translateY(100%)' },
          '100%': { transform: 'translateY(0)' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: '1' },
          '50%':      { opacity: '0.5' },
        },
      },
    },
  },
  plugins: [],
};
