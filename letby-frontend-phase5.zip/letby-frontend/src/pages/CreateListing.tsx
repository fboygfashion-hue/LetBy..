export const CreateListing = () => <div className="p-4 font-display text-2xl font-bold text-ink">Create Listing — Phase 6</div>;
