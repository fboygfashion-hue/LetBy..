import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Zap, TrendingUp } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { useTelegram } from '@/hooks/useTelegram';
import { ProductCard } from '@/components/ui/ProductCard';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';
import type { Listing, Category } from '@/types';

export const Home = () => {
  useTelegram();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [featured, setFeatured]     = useState<Listing[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading]       = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [listingsRes, catsRes] = await Promise.all([
          api.get<{ success: boolean; data: { data: Listing[] } }>('/listings?limit=6&sort=recent'),
          api.get<{ success: boolean; data: Category[] }>('/listings/categories'),
        ]);
        setFeatured(listingsRes.data.data.data);
        setCategories(catsRes.data.data);
      } catch {
        // silent — skeletons stay if API is down
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="bg-brand px-4 pt-12 pb-6">
        <p className="font-display text-2xl font-bold text-white leading-tight">
          LetBy
          <span className="block text-sm font-sans font-normal text-white/70 mt-0.5">
            Ethiopia's Trusted Marketplace
          </span>
        </p>

        {/* Trust pills */}
        <div className="flex gap-2 mt-4 flex-wrap">
          {[
            { icon: ShieldCheck, text: 'Verified Sellers' },
            { icon: Zap,         text: 'Fast Response' },
            { icon: TrendingUp,  text: 'Best Prices' },
          ].map(({ icon: Icon, text }) => (
            <span key={text}
              className="flex items-center gap-1 text-2xs font-medium bg-white/15
                         text-white px-2.5 py-1 rounded-full">
              <Icon className="w-3 h-3" />
              {text}
            </span>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="px-4">
        <h2 className="font-display text-base font-bold text-ink mb-3">Browse by Category</h2>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide -mx-1 px-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => navigate(`/marketplace?category=${cat.slug}`)}
              className="flex-shrink-0 flex flex-col items-center gap-1 bg-surface rounded-xl
                         px-3 py-2.5 shadow-card active:scale-95 transition-transform"
            >
              <span className="text-xl">{cat.icon}</span>
              <span className="text-2xs font-medium text-ink-secondary whitespace-nowrap">
                {cat.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent listings */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-base font-bold text-ink">Recent Listings</h2>
          <button
            onClick={() => navigate('/marketplace')}
            className="text-xs text-brand font-semibold"
          >
            See all →
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => <ProductCardSkeleton key={i} />)
            : featured.map((l) => <ProductCard key={l.id} listing={l} />)
          }
        </div>
      </div>
    </div>
  );
};
