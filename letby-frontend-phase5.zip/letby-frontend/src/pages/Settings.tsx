export const Settings = () => <div className="p-4 font-display text-2xl font-bold text-ink">Settings — Phase 6</div>;
