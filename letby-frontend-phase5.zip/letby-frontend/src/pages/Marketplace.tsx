import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '@/lib/api';
import { SearchBar } from '@/components/ui/SearchBar';
import { ProductCard } from '@/components/ui/ProductCard';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';
import type { Listing } from '@/types';

export const Marketplace = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [listings, setListings] = useState<Listing[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [total,    setTotal]    = useState(0);
  const [page,     setPage]     = useState(1);
  const [hasMore,  setHasMore]  = useState(false);
  const [query,    setQuery]    = useState(searchParams.get('q') ?? '');

  const category = searchParams.get('category') ?? '';

  const fetchListings = useCallback(async (p = 1, reset = true) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(p),
        limit: '10',
        ...(query    && { q: query }),
        ...(category && { category }),
      });

      const { data } = await api.get<{
        success: boolean;
        data: { data: Listing[]; total: number; hasMore: boolean };
      }>(`/listings?${params}`);

      setListings((prev) => reset ? data.data.data : [...prev, ...data.data.data]);
      setTotal(data.data.total);
      setHasMore(data.data.hasMore);
      setPage(p);
    } finally {
      setLoading(false);
    }
  }, [query, category]);

  useEffect(() => { fetchListings(1, true); }, [query, category]);

  const handleSearch = (v: string) => {
    setQuery(v);
    setSearchParams(v ? { q: v } : {});
  };

  return (
    <div className="space-y-4">
      {/* Sticky search header */}
      <div className="sticky top-0 z-30 bg-surface-raised/95 backdrop-blur-md px-4 pt-4 pb-3
                      border-b border-gray-100">
        <SearchBar value={query} onChange={setQuery} onSubmit={handleSearch} />

        {/* Active filter chips */}
        {(query || category) && (
          <div className="flex gap-2 mt-2">
            {query && (
              <span className="text-2xs bg-brand-muted text-brand font-semibold px-2.5 py-1
                               rounded-full flex items-center gap-1">
                "{query}"
                <button onClick={() => handleSearch('')} className="ml-0.5">×</button>
              </span>
            )}
            {category && (
              <span className="text-2xs bg-brand-muted text-brand font-semibold px-2.5 py-1
                               rounded-full flex items-center gap-1">
                {category}
                <button
                  onClick={() => setSearchParams(query ? { q: query } : {})}
                  className="ml-0.5"
                >×</button>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Results count */}
      {!loading && (
        <p className="px-4 text-xs text-ink-muted">
          {total.toLocaleString()} listing{total !== 1 ? 's' : ''} found
        </p>
      )}

      {/* Listings grid */}
      <div className="px-4 grid grid-cols-2 gap-3">
        {loading && listings.length === 0
          ? Array.from({ length: 8 }).map((_, i) => <ProductCardSkeleton key={i} />)
          : listings.map((l) => <ProductCard key={l.id} listing={l} />)
        }
      </div>

      {/* Load more */}
      {hasMore && !loading && (
        <div className="px-4 pb-4">
          <button
            onClick={() => fetchListings(page + 1, false)}
            className="w-full py-3 text-sm font-semibold text-brand border-2 border-brand/30
                       rounded-xl hover:bg-brand-muted transition-colors"
          >
            Load more
          </button>
        </div>
      )}

      {/* Empty state */}
      {!loading && listings.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
          <span className="text-5xl mb-4">🔍</span>
          <p className="font-display text-lg font-bold text-ink">No listings found</p>
          <p className="text-sm text-ink-muted mt-1">
            Try a different search or check back later
          </p>
        </div>
      )}
    </div>
  );
};
