export const Verification = () => <div className="p-4 font-display text-2xl font-bold text-ink">Verification — Phase 7</div>;
