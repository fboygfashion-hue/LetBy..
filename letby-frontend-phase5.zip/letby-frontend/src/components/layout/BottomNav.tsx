import { Home, Search, PlusSquare, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { haptic } from '@/lib/telegram';
import { useAuthStore } from '@/store/auth.store';

const navItems = [
  { icon: Home,       label: 'Home',   path: '/' },
  { icon: Search,     label: 'Browse', path: '/marketplace' },
  { icon: PlusSquare, label: 'Sell',   path: '/sell' },
  { icon: User,       label: 'Profile',path: '/profile' },
];

export const BottomNav = () => {
  const navigate  = useNavigate();
  const { pathname } = useLocation();
  const { user }  = useAuthStore();

  const handleNav = (path: string) => {
    haptic.light();
    navigate(path);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-100
                    safe-area-pb">
      <div className="flex items-stretch h-14">
        {navItems.map(({ icon: Icon, label, path }) => {
          const active = pathname === path || (path !== '/' && pathname.startsWith(path));
          const isSell = path === '/sell';

          return (
            <button
              key={path}
              onClick={() => handleNav(path)}
              className={`flex-1 flex flex-col items-center justify-center gap-0.5 transition-colors
                ${isSell ? 'text-white' : active ? 'text-brand' : 'text-ink-muted'}`}
            >
              {isSell ? (
                // Sell button — elevated brand CTA
                <span className="w-10 h-10 rounded-xl bg-brand flex items-center justify-center
                                 shadow-lg shadow-brand/30 -mt-3">
                  <Icon className="w-5 h-5 text-white" />
                </span>
              ) : (
                <>
                  <Icon className={`w-5 h-5 ${active ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
                  <span className={`text-2xs font-medium ${active ? 'text-brand' : 'text-ink-muted'}`}>
                    {label}
                  </span>
                </>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
