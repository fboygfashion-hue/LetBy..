import { Outlet } from 'react-router-dom';
import { BottomNav } from './BottomNav';
import { ToastContainer } from '@/components/ui/Toast';

export const AppShell = () => (
  <div className="min-h-screen bg-surface-raised font-sans">
    <ToastContainer />
    {/* Page content — padded for bottom nav */}
    <main className="pb-16">
      <Outlet />
    </main>
    <BottomNav />
  </div>
);
