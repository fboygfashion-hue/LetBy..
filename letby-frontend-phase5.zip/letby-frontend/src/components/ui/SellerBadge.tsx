import { ShieldCheck, ShieldAlert } from 'lucide-react';

interface Props {
  isVerified: boolean;
  size?: 'sm' | 'md';
}

export const SellerBadge = ({ isVerified, size = 'sm' }: Props) => {
  if (isVerified) {
    return (
      <span
        className={`inline-flex items-center gap-1 rounded-full font-semibold bg-verified-bg text-verified-text
          ${size === 'sm' ? 'text-2xs px-2 py-0.5' : 'text-xs px-2.5 py-1'}`}
      >
        <ShieldCheck className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
        VERIFIED
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-semibold bg-gray-100 text-ink-muted
        ${size === 'sm' ? 'text-2xs px-2 py-0.5' : 'text-xs px-2.5 py-1'}`}
    >
      <ShieldAlert className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      UNVERIFIED
    </span>
  );
};
