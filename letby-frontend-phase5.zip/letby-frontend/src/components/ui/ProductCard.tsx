import { MapPin, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SellerBadge } from './SellerBadge';
import { formatETB, conditionLabel } from '@/lib/api';
import { haptic } from '@/lib/telegram';
import type { Listing } from '@/types';

interface Props {
  listing: Listing;
}

export const ProductCard = ({ listing }: Props) => {
  const navigate = useNavigate();
  const coverImage = listing.images[0]?.url;
  const isVerified = listing.seller.sellerProfile?.isVerified ?? false;

  const handleTap = () => {
    haptic.light();
    navigate(`/listing/${listing.id}`);
  };

  return (
    <div
      onClick={handleTap}
      className="bg-surface rounded-2xl shadow-card overflow-hidden cursor-pointer
                 active:scale-[0.98] transition-all duration-150 hover:shadow-card-hover"
    >
      {/* Image */}
      <div className="relative w-full aspect-[4/3] bg-surface-muted overflow-hidden">
        {coverImage ? (
          <img
            src={coverImage}
            alt={listing.title}
            loading="lazy"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-3xl">📦</div>
        )}

        {/* Condition pill */}
        <span className="absolute top-2 left-2 text-2xs font-semibold bg-black/60 text-white
                         backdrop-blur-sm px-2 py-0.5 rounded-full">
          {conditionLabel[listing.condition]}
        </span>

        {/* Negotiable pill */}
        {listing.isNegotiable && (
          <span className="absolute top-2 right-2 text-2xs font-semibold bg-accent/90
                           text-white px-2 py-0.5 rounded-full">
            Negotiable
          </span>
        )}
      </div>

      {/* Content */}
      <div className="p-3 space-y-1.5">
        {/* Title */}
        <h3 className="text-sm font-semibold text-ink leading-tight line-clamp-2">
          {listing.title}
        </h3>

        {/* Price */}
        <p className="font-display text-base font-bold text-brand">
          {formatETB(listing.price)}
        </p>

        {/* Location */}
        <div className="flex items-center gap-1 text-ink-muted">
          <MapPin className="w-3 h-3 flex-shrink-0" />
          <span className="text-2xs truncate">{listing.location}</span>
        </div>

        {/* Footer: badge + rating */}
        <div className="flex items-center justify-between pt-0.5">
          <SellerBadge isVerified={isVerified} size="sm" />
          {listing.avgRating && listing.reviewCount ? (
            <div className="flex items-center gap-0.5 text-ink-muted">
              <Star className="w-3 h-3 fill-accent text-accent" />
              <span className="text-2xs font-medium">
                {listing.avgRating.toFixed(1)}
                <span className="font-normal"> ({listing.reviewCount})</span>
              </span>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
