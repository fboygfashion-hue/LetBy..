import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useState } from 'react';
import { useUIStore } from '@/store/ui.store';

interface Props {
  value: string;
  onChange: (v: string) => void;
  onSubmit?: (v: string) => void;
  placeholder?: string;
}

export const SearchBar = ({
  value,
  onChange,
  onSubmit,
  placeholder = 'Search listings...',
}: Props) => {
  const { setFilterOpen } = useUIStore();

  return (
    <div className="flex gap-2 items-center">
      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted" />
        <input
          type="search"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onSubmit?.(value)}
          placeholder={placeholder}
          className="w-full pl-9 pr-8 py-2.5 bg-surface-muted rounded-xl text-sm text-ink
                     placeholder-ink-muted focus:outline-none focus:ring-2 focus:ring-brand/30
                     focus:bg-white transition-all"
        />
        {value && (
          <button
            onClick={() => onChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      <button
        onClick={() => setFilterOpen(true)}
        className="w-10 h-10 rounded-xl bg-surface-muted flex items-center justify-center
                   text-ink-secondary hover:bg-brand hover:text-white transition-all flex-shrink-0"
      >
        <SlidersHorizontal className="w-4 h-4" />
      </button>
    </div>
  );
};
