import { CheckCircle, XCircle, Info, AlertTriangle, X } from 'lucide-react';
import { useUIStore, type ToastType } from '@/store/ui.store';

const icons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle className="w-4 h-4 text-verified-DEFAULT flex-shrink-0" />,
  error:   <XCircle className="w-4 h-4 text-risk-high flex-shrink-0" />,
  info:    <Info className="w-4 h-4 text-brand flex-shrink-0" />,
  warning: <AlertTriangle className="w-4 h-4 text-risk-medium flex-shrink-0" />,
};

const borders: Record<ToastType, string> = {
  success: 'border-l-4 border-verified-DEFAULT',
  error:   'border-l-4 border-risk-high',
  info:    'border-l-4 border-brand',
  warning: 'border-l-4 border-risk-medium',
};

export const ToastContainer = () => {
  const { toasts, removeToast } = useUIStore();

  if (!toasts.length) return null;

  return (
    <div className="fixed top-4 left-4 right-4 z-50 space-y-2 animate-fade-in">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`flex items-center gap-3 bg-white rounded-xl shadow-modal px-4 py-3 ${borders[toast.type]}`}
        >
          {icons[toast.type]}
          <span className="text-sm text-ink font-medium flex-1">{toast.message}</span>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-ink-muted hover:text-ink transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
