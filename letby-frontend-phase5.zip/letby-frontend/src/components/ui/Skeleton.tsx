import { cn } from '@/lib/utils';

interface Props { className?: string }

export const Skeleton = ({ className }: Props) => (
  <div className={cn('animate-pulse-soft bg-surface-muted rounded-lg', className)} />
);

export const ProductCardSkeleton = () => (
  <div className="bg-surface rounded-2xl shadow-card overflow-hidden">
    <Skeleton className="w-full aspect-[4/3] rounded-none" />
    <div className="p-3 space-y-2">
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-5 w-1/2" />
      <Skeleton className="h-3 w-full" />
      <div className="flex justify-between items-center pt-1">
        <Skeleton className="h-5 w-20 rounded-full" />
        <Skeleton className="h-3 w-12" />
      </div>
    </div>
  </div>
);
