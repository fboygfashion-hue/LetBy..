import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { Home } from '@/pages/Home';
import { Marketplace } from '@/pages/Marketplace';

// Lazy-loaded pages (Phase 6+)
import { lazy, Suspense } from 'react';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';

const ListingDetail  = lazy(() => import('@/pages/ListingDetail').then((m) => ({ default: m.ListingDetail })));
const SellerProfile  = lazy(() => import('@/pages/SellerProfile').then((m) => ({ default: m.SellerProfile })));
const CreateListing  = lazy(() => import('@/pages/CreateListing').then((m) => ({ default: m.CreateListing })));
const Verification   = lazy(() => import('@/pages/Verification').then((m) => ({ default: m.Verification })));
const Settings       = lazy(() => import('@/pages/Settings').then((m) => ({ default: m.Settings })));
const AdminDashboard = lazy(() => import('@/pages/admin/Dashboard').then((m) => ({ default: m.AdminDashboard })));

const PageLoader = () => (
  <div className="grid grid-cols-2 gap-3 p-4">
    {Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)}
  </div>
);

export const App = () => (
  <BrowserRouter>
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/"                    element={<Home />} />
          <Route path="/marketplace"         element={<Marketplace />} />
          <Route path="/listing/:id"         element={<ListingDetail />} />
          <Route path="/seller/:id"          element={<SellerProfile />} />
          <Route path="/sell"                element={<CreateListing />} />
          <Route path="/profile"             element={<Settings />} />
          <Route path="/verify"              element={<Verification />} />
          <Route path="/admin"               element={<AdminDashboard />} />
          <Route path="*"                    element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Suspense>
  </BrowserRouter>
);
