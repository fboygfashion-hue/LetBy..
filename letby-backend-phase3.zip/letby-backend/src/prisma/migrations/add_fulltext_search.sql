-- Migration: Add full-text search to listings
-- Run this AFTER prisma migrate dev

-- Create GIN index for fast full-text search on title + description
-- This makes "Gaming Laptop", "iPhone 13" searches fast even at 100k listings

CREATE INDEX IF NOT EXISTS listings_fts_idx
ON "Listing"
USING GIN (
  to_tsvector('english', title || ' ' || description)
);

-- Add tsvector column for efficient search (optional for V2 scaling)
-- ALTER TABLE "Listing" ADD COLUMN search_vector tsvector
--   GENERATED ALWAYS AS (to_tsvector('english', title || ' ' || description)) STORED;
