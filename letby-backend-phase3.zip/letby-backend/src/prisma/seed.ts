import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const CATEGORIES = [
  { name: 'Electronics', slug: 'electronics', icon: '📱', sortOrder: 1 },
  { name: 'Laptops & Computers', slug: 'laptops', icon: '💻', sortOrder: 2 },
  { name: 'Phones', slug: 'phones', icon: '📲', sortOrder: 3 },
  { name: 'Vehicles', slug: 'vehicles', icon: '🚗', sortOrder: 4 },
  { name: 'Furniture', slug: 'furniture', icon: '🛋️', sortOrder: 5 },
  { name: 'Clothing', slug: 'clothing', icon: '👕', sortOrder: 6 },
  { name: 'Apartments', slug: 'apartments', icon: '🏠', sortOrder: 7 },
  { name: 'Appliances', slug: 'appliances', icon: '🔌', sortOrder: 8 },
  { name: 'Sports & Fitness', slug: 'sports', icon: '⚽', sortOrder: 9 },
  { name: 'Books & Education', slug: 'books', icon: '📚', sortOrder: 10 },
  { name: 'Services', slug: 'services', icon: '🛠️', sortOrder: 11 },
  { name: 'Other', slug: 'other', icon: '📦', sortOrder: 12 },
];

async function main() {
  console.log('🌱 Seeding LetBy database...');

  // Upsert categories (safe to re-run)
  for (const cat of CATEGORIES) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: {},
      create: cat,
    });
  }

  console.log(`✅ ${CATEGORIES.length} categories seeded`);
  console.log('✅ Seed complete');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
