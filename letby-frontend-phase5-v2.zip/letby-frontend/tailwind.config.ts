/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: '#0F1319',
          card:    '#161D2B',
          input:   '#1E2736',
          hover:   '#1A2336',
          border:  '#232E42',
        },
        blue: {
          DEFAULT: '#4BA3E3',
          dark:    '#2E86C8',
          muted:   '#1A3A5C',
          glow:    'rgba(75,163,227,0.15)',
        },
        verified: {
          DEFAULT: '#4BA3E3',
          bg:      'rgba(75,163,227,0.12)',
        },
        risk: {
          low:    '#22C55E',
          medium: '#F59E0B',
          high:   '#EF4444',
        },
        ink: {
          DEFAULT:   '#EAECF2',
          secondary: '#8892A4',
          muted:     '#4E5A6E',
          inverse:   '#0F1319',
        },
        etb: '#4BA3E3',
        stock: {
          ok:  '#8892A4',
          low: '#FF6B6B',
        },
      },
      fontFamily: {
        sans:    ['"DM Sans"', 'system-ui', 'sans-serif'],
        display: ['"Syne"', 'system-ui', 'sans-serif'],
        mono:    ['"DM Mono"', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        card:     '0 1px 3px rgba(0,0,0,0.4)',
        'card-lg':'0 4px 20px rgba(0,0,0,0.5)',
        blue:     '0 4px 20px rgba(75,163,227,0.25)',
      },
      animation: {
        'fade-up':    'fadeUp 0.3s ease-out',
        'fade-in':    'fadeIn 0.2s ease-out',
        'slide-up':   'slideUp 0.35s cubic-bezier(0.32,0.72,0,1)',
        'pulse-soft': 'pulseSoft 1.5s ease-in-out infinite',
      },
      keyframes: {
        fadeUp:    { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        fadeIn:    { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp:   { '0%': { transform: 'translateY(100%)' }, '100%': { transform: 'translateY(0)' } },
        pulseSoft: { '0%, 100%': { opacity: '1' }, '50%': { opacity: '0.4' } },
      },
    },
  },
  plugins: [],
};
