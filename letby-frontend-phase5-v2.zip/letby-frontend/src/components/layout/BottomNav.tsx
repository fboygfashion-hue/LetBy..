import { ShoppingBag, BarChart2, Settings, Package } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { haptic } from '@/lib/telegram';
import { useAuthStore } from '@/store/auth.store';

const buyerNav  = [
  { icon: Package,     label: 'Home',     path: '/' },
  { icon: ShoppingBag, label: 'Browse',   path: '/marketplace' },
  { icon: BarChart2,   label: 'Orders',   path: '/orders' },
  { icon: Settings,    label: 'Settings', path: '/profile' },
];
const sellerNav = [
  { icon: Package,     label: 'Products', path: '/sell/products' },
  { icon: ShoppingBag, label: 'Orders',   path: '/sell/orders' },
  { icon: BarChart2,   label: 'Stats',    path: '/sell/stats' },
  { icon: Settings,    label: 'Settings', path: '/profile' },
];

export const BottomNav = () => {
  const navigate       = useNavigate();
  const { pathname }   = useLocation();
  const { user }       = useAuthStore();
  const items          = user?.role === 'SELLER' ? sellerNav : buyerNav;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-bg-card border-t border-bg-border safe-area-pb">
      <div className="flex items-stretch h-14">
        {items.map(({ icon: Icon, label, path }) => {
          const active = pathname === path || (path !== '/' && pathname.startsWith(path));
          return (
            <button key={path}
              onClick={() => { haptic.light(); navigate(path); }}
              className="flex-1 flex flex-col items-center justify-center gap-0.5">
              <Icon className={`w-5 h-5 ${active ? 'text-blue' : 'text-ink-muted'}`} strokeWidth={active ? 2.5 : 1.8} />
              <span className={`text-2xs font-medium ${active ? 'text-blue' : 'text-ink-muted'}`}>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
