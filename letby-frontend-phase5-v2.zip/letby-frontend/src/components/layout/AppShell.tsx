import { Outlet } from 'react-router-dom';
import { BottomNav } from './BottomNav';
import { ToastContainer } from '@/components/ui/Toast';

export const AppShell = () => (
  <div className="min-h-screen bg-bg font-sans">
    <ToastContainer />
    <main className="pb-16"><Outlet /></main>
    <BottomNav />
  </div>
);
