export const Skeleton = ({ className = '' }: { className?: string }) => (
  <div className={`animate-pulse-soft bg-bg-input rounded-xl ${className}`} />
);

export const ProductCardSkeleton = () => (
  <div className="flex items-center gap-3 bg-bg-card rounded-xl p-3 border border-bg-border">
    <Skeleton className="w-16 h-16 flex-shrink-0" />
    <div className="flex-1 space-y-2">
      <Skeleton className="h-3.5 w-3/4" />
      <Skeleton className="h-4 w-1/2" />
      <Skeleton className="h-3 w-full" />
    </div>
  </div>
);
