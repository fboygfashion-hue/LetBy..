import { useNavigate } from 'react-router-dom';
import { haptic } from '@/lib/telegram';
import { formatETB, conditionLabel } from '@/lib/api';
import type { Listing } from '@/types';

// LIST-VIEW card — matches Image 3 (dark theme, horizontal layout)
export const ProductCard = ({ listing }: { listing: Listing }) => {
  const navigate = useNavigate();
  const cover    = listing.images[0]?.url;
  const isVerified = listing.seller.sellerProfile?.isVerified ?? false;

  return (
    <div onClick={() => { haptic.light(); navigate(`/listing/${listing.id}`); }}
      className="flex items-center gap-3 bg-bg-card rounded-xl p-3 border border-bg-border
                 active:bg-bg-hover transition-colors cursor-pointer">

      {/* Thumbnail */}
      <div className="w-16 h-16 rounded-xl bg-bg-input flex-shrink-0 overflow-hidden">
        {cover
          ? <img src={cover} alt={listing.title} className="w-full h-full object-cover" loading="lazy" />
          : <div className="w-full h-full flex items-center justify-center text-2xl">📦</div>
        }
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-ink line-clamp-1">{listing.title}</p>
        <p className="text-base font-bold text-etb mt-0.5">{formatETB(listing.price)} ETB</p>
        <div className="flex items-center gap-3 mt-1">
          <span className="text-2xs text-ink-secondary">
            IN STOCK: <span className="font-semibold text-ink">{listing.viewCount ?? '—'}</span>
          </span>
          <span className="text-2xs text-ink-secondary">
            CONDITION: <span className="font-semibold text-ink">{conditionLabel[listing.condition]}</span>
          </span>
        </div>
      </div>

      {/* Verified dot */}
      {isVerified && (
        <div className="w-2 h-2 rounded-full bg-blue flex-shrink-0" title="Verified Seller" />
      )}
    </div>
  );
};
