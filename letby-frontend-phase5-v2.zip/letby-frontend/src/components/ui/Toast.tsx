import { CheckCircle, XCircle, Info, AlertTriangle, X } from 'lucide-react';
import { useUIStore, type ToastType } from '@/store/ui.store';

const icons: Record<ToastType, React.ReactNode> = {
  success: <CheckCircle className="w-4 h-4 text-risk-low flex-shrink-0" />,
  error:   <XCircle    className="w-4 h-4 text-risk-high flex-shrink-0" />,
  info:    <Info        className="w-4 h-4 text-blue flex-shrink-0" />,
  warning: <AlertTriangle className="w-4 h-4 text-risk-medium flex-shrink-0" />,
};

const borders: Record<ToastType, string> = {
  success: 'border-l-4 border-risk-low',
  error:   'border-l-4 border-risk-high',
  info:    'border-l-4 border-blue',
  warning: 'border-l-4 border-risk-medium',
};

export const ToastContainer = () => {
  const { toasts, removeToast } = useUIStore();
  if (!toasts.length) return null;
  return (
    <div className="fixed top-4 left-4 right-4 z-50 space-y-2 animate-fade-in">
      {toasts.map((t) => (
        <div key={t.id}
          className={`flex items-center gap-3 bg-bg-card rounded-xl shadow-card-lg px-4 py-3 ${borders[t.type]}`}>
          {icons[t.type]}
          <span className="text-sm text-ink font-medium flex-1">{t.message}</span>
          <button onClick={() => removeToast(t.id)} className="text-ink-muted">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
