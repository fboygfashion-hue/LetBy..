import { Shield } from 'lucide-react';
import type { TrustLabel } from '@/types';

interface Props {
  score: number;
  label: TrustLabel;
  showLabel?: boolean;
}

const labelColors: Record<TrustLabel, string> = {
  'LOW RISK':    'text-risk-low',
  'MEDIUM RISK': 'text-risk-medium',
  'HIGH RISK':   'text-risk-high',
  'UNVERIFIED':  'text-ink-muted',
};

const barColors: Record<TrustLabel, string> = {
  'LOW RISK':    'bg-risk-low',
  'MEDIUM RISK': 'bg-risk-medium',
  'HIGH RISK':   'bg-risk-high',
  'UNVERIFIED':  'bg-gray-300',
};

export const TrustScore = ({ score, label, showLabel = true }: Props) => {
  const pct = (score / 5) * 100;

  return (
    <div className="flex items-center gap-2">
      <Shield className={`w-4 h-4 flex-shrink-0 ${labelColors[label]}`} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-0.5">
          <span className={`text-2xs font-semibold tracking-wide ${labelColors[label]}`}>
            {showLabel ? label : `${score.toFixed(1)}/5`}
          </span>
          {showLabel && (
            <span className="text-2xs text-ink-muted">{score.toFixed(1)}/5</span>
          )}
        </div>
        <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${barColors[label]}`}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
    </div>
  );
};
