import axios, { AxiosError } from 'axios';
import type { ApiError } from '@/types';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:3000/api',
  timeout: 15000, // 15s — generous for slow Ethiopian networks
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('letby_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle auth errors globally
api.interceptors.response.use(
  (res) => res,
  (error: AxiosError<ApiError>) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('letby_token');
      // Store will react to token removal via auth store
      window.dispatchEvent(new Event('letby:unauthorized'));
    }
    return Promise.reject(error);
  }
);

// ETB formatting helper — used everywhere in the UI
export const formatETB = (cents: number): string => {
  const etb = Math.floor(cents / 100);
  return `${etb.toLocaleString('en-ET')} ETB`;
};

// Condition display labels
export const conditionLabel: Record<string, string> = {
  NEW: 'New',
  USED_EXCELLENT: 'Used — Excellent',
  USED_GOOD: 'Used — Good',
  USED_FAIR: 'Used — Fair',
};
