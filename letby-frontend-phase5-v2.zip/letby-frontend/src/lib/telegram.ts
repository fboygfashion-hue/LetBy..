import type { TelegramWebApp } from '@/types';

const isTelegram = (): boolean =>
  typeof window !== 'undefined' &&
  typeof window.Telegram !== 'undefined' &&
  typeof window.Telegram.WebApp !== 'undefined';

export const tg = (): TelegramWebApp | null =>
  isTelegram() ? window.Telegram.WebApp : null;

export const getInitData = (): string => {
  if (isTelegram()) return window.Telegram.WebApp.initData;
  // Dev fallback — use env var for local testing
  return import.meta.env.VITE_DEV_INIT_DATA ?? '';
};

export const getTelegramUser = () => {
  if (isTelegram()) return window.Telegram.WebApp.initDataUnsafe.user ?? null;
  return null;
};

export const haptic = {
  light: () => tg()?.HapticFeedback.impactOccurred('light'),
  medium: () => tg()?.HapticFeedback.impactOccurred('medium'),
  success: () => tg()?.HapticFeedback.notificationOccurred('success'),
  error: () => tg()?.HapticFeedback.notificationOccurred('error'),
  warning: () => tg()?.HapticFeedback.notificationOccurred('warning'),
};
