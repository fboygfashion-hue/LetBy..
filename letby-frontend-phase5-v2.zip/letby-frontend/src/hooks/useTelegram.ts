import { useEffect } from 'react';
import { tg, haptic } from '@/lib/telegram';

export const useTelegram = () => {
  useEffect(() => {
    const app = tg();
    if (!app) return;
    // Tell Telegram the app is ready — removes loading screen
    app.ready();
    // Expand to full height
    app.expand();
  }, []);

  return { tg: tg(), haptic };
};
