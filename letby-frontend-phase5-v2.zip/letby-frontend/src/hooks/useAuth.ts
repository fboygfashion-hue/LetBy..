import { useEffect } from 'react';
import { useAuthStore } from '@/store/auth.store';

export const useAuth = () => {
  const { user, token, isLoading, isAuthenticated, login, logout } = useAuthStore();

  useEffect(() => {
    // Auto-login when Mini App opens
    if (!token) {
      login();
    }

    // Handle 401 from any API call
    const handler = () => logout();
    window.addEventListener('letby:unauthorized', handler);
    return () => window.removeEventListener('letby:unauthorized', handler);
  }, []);

  return { user, token, isLoading, isAuthenticated, login, logout };
};
