export type Role = 'BUYER' | 'SELLER' | 'ADMIN';
export type ListingStatus = 'DRAFT' | 'ACTIVE' | 'SOLD' | 'PAUSED' | 'REMOVED';
export type Condition = 'NEW' | 'USED_EXCELLENT' | 'USED_GOOD' | 'USED_FAIR';
export type TrustLabel = 'LOW RISK' | 'MEDIUM RISK' | 'HIGH RISK' | 'UNVERIFIED';
export type VerificationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface User {
  id: string;
  telegramId: string;
  telegramUsername?: string;
  firstName: string;
  lastName?: string;
  photoUrl?: string;
  role: Role;
  sellerProfile?: SellerProfile | null;
  verificationReq?: { status: VerificationStatus; submittedAt: string } | null;
  createdAt: string;
}

export interface SellerProfile {
  shopName: string;
  shopDescription?: string;
  shopBanner?: string;
  isVerified: boolean;
  verifiedAt?: string;
  totalSales: number;
  avgResponseMin: number;
  scamReports: number;
}

export interface TrustScore {
  score: number;
  label: TrustLabel;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon?: string;
}

export interface ListingImage {
  id: string;
  url: string;
  sortOrder: number;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number; // ETB cents
  isNegotiable: boolean;
  condition: Condition;
  location: string;
  status: ListingStatus;
  viewCount: number;
  images: ListingImage[];
  category: Category;
  seller: {
    id: string;
    firstName: string;
    lastName?: string;
    telegramUsername?: string;
    sellerProfile?: SellerProfile | null;
  };
  trustScore?: TrustScore;
  reviewCount?: number;
  avgRating?: number;
  createdAt: string;
}

export interface Review {
  id: string;
  rating: number;
  comment?: string;
  isVerified: boolean;
  author: { firstName: string; lastName?: string; photoUrl?: string };
  createdAt: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
}

export interface ApiError {
  success: false;
  error: string;
  message?: string;
}

// Telegram WebApp types
declare global {
  interface Window {
    Telegram: {
      WebApp: TelegramWebApp;
    };
  }
}

export interface TelegramWebApp {
  initData: string;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      photo_url?: string;
      language_code?: string;
    };
    auth_date: number;
    hash: string;
  };
  colorScheme: 'light' | 'dark';
  themeParams: Record<string, string>;
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  ready: () => void;
  expand: () => void;
  close: () => void;
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback: (confirmed: boolean) => void) => void;
  HapticFeedback: {
    impactOccurred: (style: 'light' | 'medium' | 'heavy') => void;
    notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
  };
  BackButton: {
    show: () => void;
    hide: () => void;
    onClick: (callback: () => void) => void;
  };
  MainButton: {
    text: string;
    color: string;
    isVisible: boolean;
    isActive: boolean;
    show: () => void;
    hide: () => void;
    enable: () => void;
    disable: () => void;
    setText: (text: string) => void;
    onClick: (callback: () => void) => void;
    offClick: (callback: () => void) => void;
    showProgress: (leaveActive?: boolean) => void;
    hideProgress: () => void;
  };
}
