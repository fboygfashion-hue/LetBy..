import { create } from 'zustand';
import { api } from '@/lib/api';
import { getInitData } from '@/lib/telegram';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: () => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: localStorage.getItem('letby_token'),
  isLoading: false,
  isAuthenticated: !!localStorage.getItem('letby_token'),

  login: async () => {
    set({ isLoading: true });
    try {
      const initData = getInitData();
      if (!initData) throw new Error('No Telegram initData');

      const { data } = await api.post<{ success: boolean; data: { token: string; user: User } }>(
        '/auth/telegram',
        { initData }
      );

      localStorage.setItem('letby_token', data.data.token);
      set({
        token: data.data.token,
        user: data.data.user,
        isAuthenticated: true,
      });
    } catch (err) {
      console.error('Auth failed:', err);
      set({ isAuthenticated: false });
    } finally {
      set({ isLoading: false });
    }
  },

  logout: () => {
    localStorage.removeItem('letby_token');
    set({ user: null, token: null, isAuthenticated: false });
  },

  setUser: (user) => set({ user }),
}));
