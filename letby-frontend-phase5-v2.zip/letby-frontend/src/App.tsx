import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { Home }        from '@/pages/Home';
import { Marketplace } from '@/pages/Marketplace';
import { Settings }    from '@/pages/Settings';
import { Verification } from '@/pages/Verification';
import { CreateListing } from '@/pages/CreateListing';
import { Checkout }    from '@/pages/Checkout';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';

const ListingDetail  = lazy(() => import('@/pages/ListingDetail').then((m) => ({ default: m.ListingDetail })));
const SellerProfile  = lazy(() => import('@/pages/SellerProfile').then((m) => ({ default: m.SellerProfile })));
const AdminDashboard = lazy(() => import('@/pages/admin/Dashboard').then((m) => ({ default: m.AdminDashboard })));

const Loader = () => (
  <div className="space-y-2.5 p-4">
    {Array.from({ length: 5 }).map((_, i) => <ProductCardSkeleton key={i} />)}
  </div>
);

export const App = () => (
  <BrowserRouter>
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/"               element={<Home />} />
          <Route path="/marketplace"    element={<Marketplace />} />
          <Route path="/listing/:id"    element={<ListingDetail />} />
          <Route path="/seller/:id"     element={<SellerProfile />} />
          <Route path="/sell"           element={<CreateListing />} />
          <Route path="/sell/products"  element={<Marketplace />} />
          <Route path="/checkout"       element={<Checkout />} />
          <Route path="/profile"        element={<Settings />} />
          <Route path="/verify"         element={<Verification />} />
          <Route path="/admin"          element={<AdminDashboard />} />
          <Route path="*"               element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Suspense>
  </BrowserRouter>
);
