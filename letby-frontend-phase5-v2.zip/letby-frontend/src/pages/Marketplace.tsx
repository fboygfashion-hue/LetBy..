import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '@/lib/api';
import { SearchBar } from '@/components/ui/SearchBar';
import { ProductCard } from '@/components/ui/ProductCard';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';
import type { Listing } from '@/types';

const CATEGORIES = ['All', 'Electronics', 'Fashion', 'Accessories', 'Vehicles', 'Furniture', 'Phones', 'Appliances'];

export const Marketplace = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [total,    setTotal]    = useState(0);
  const [page,     setPage]     = useState(1);
  const [hasMore,  setHasMore]  = useState(false);
  const [query,    setQuery]    = useState(searchParams.get('q') ?? '');
  const [active,   setActive]   = useState('All');

  const fetch = useCallback(async (p = 1, reset = true) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(p), limit: '15',
        ...(query  && { q: query }),
        ...(active !== 'All' && { category: active.toLowerCase() }),
      });
      const { data } = await api.get<{ success: boolean; data: { data: Listing[]; total: number; hasMore: boolean } }>(
        `/listings?${params}`
      );
      setListings((prev) => reset ? data.data.data : [...prev, ...data.data.data]);
      setTotal(data.data.total);
      setHasMore(data.data.hasMore);
      setPage(p);
    } finally { setLoading(false); }
  }, [query, active]);

  useEffect(() => { fetch(1, true); }, [query, active]);

  return (
    <div className="min-h-screen bg-bg">
      {/* Sticky header */}
      <div className="sticky top-0 z-30 bg-bg/95 backdrop-blur-md px-4 pt-4 pb-3 border-b border-bg-border">
        <div className="flex items-center justify-between mb-3">
          <h1 className="font-display text-lg font-bold text-ink">Product List</h1>
        </div>
        <SearchBar value={query} onChange={setQuery} onSubmit={(v) => setSearchParams(v ? { q: v } : {})} />
      </div>

      {/* Category pills */}
      <div className="flex gap-2 px-4 pt-3 overflow-x-auto scrollbar-hide pb-2">
        {CATEGORIES.map((cat) => (
          <button key={cat} onClick={() => setActive(cat)}
            className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all
              ${active === cat ? 'bg-blue text-white' : 'bg-bg-card border border-bg-border text-ink-secondary'}`}>
            {cat}
          </button>
        ))}
      </div>

      {/* Count */}
      {!loading && <p className="px-4 py-2 text-2xs text-ink-muted">{total.toLocaleString()} listings found</p>}

      {/* List */}
      <div className="px-4 space-y-2.5 pb-4">
        {loading && listings.length === 0
          ? Array.from({ length: 8 }).map((_, i) => <ProductCardSkeleton key={i} />)
          : listings.map((l) => <ProductCard key={l.id} listing={l} />)
        }
      </div>

      {hasMore && !loading && (
        <div className="px-4 pb-6">
          <button onClick={() => fetch(page + 1, false)}
            className="w-full py-3 text-sm font-semibold text-blue border border-blue/30
                       rounded-xl hover:bg-blue/10 transition-colors">
            Load more
          </button>
        </div>
      )}

      {!loading && listings.length === 0 && (
        <div className="flex flex-col items-center py-16 text-center">
          <span className="text-5xl mb-3">🔍</span>
          <p className="text-ink font-semibold">No listings found</p>
          <p className="text-sm text-ink-secondary mt-1">Try a different search</p>
        </div>
      )}
    </div>
  );
};
