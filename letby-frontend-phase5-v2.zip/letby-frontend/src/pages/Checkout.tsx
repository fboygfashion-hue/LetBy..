import { useState } from 'react';
import { ShoppingCart, MapPin, CheckCircle, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useUIStore } from '@/store/ui.store';
import { haptic } from '@/lib/telegram';

const CITIES = ['Addis Ababa', 'Dire Dawa', 'Mekelle', 'Gondar', 'Hawassa', 'Bahir Dar', 'Adama', 'Jimma'];

const PAYMENT_METHODS = [
  { id: 'cbe',     label: 'CBE',      emoji: '🏦', color: 'bg-green-900/40  border-green-600/40' },
  { id: 'telebirr',label: 'Telebirr', emoji: '📱', color: 'bg-sky-900/40    border-sky-600/40' },
  { id: 'dashen',  label: 'Dashen',   emoji: '🏛️', color: 'bg-yellow-900/40 border-yellow-600/40' },
  { id: 'awash',   label: 'Awash',    emoji: '💳', color: 'bg-red-900/40    border-red-600/40' },
];

interface Props {
  subtotal?: number;
  shippingFee?: number;
}

export const Checkout = ({ subtotal = 425000, shippingFee = 15000 }: Props) => {
  const navigate   = useNavigate();
  const { addToast } = useUIStore();
  const [fullName, setFullName]  = useState('');
  const [city,     setCity]      = useState('Addis Ababa');
  const [phone,    setPhone]     = useState('');
  const [address,  setAddress]   = useState('');
  const [payment,  setPayment]   = useState('cbe');
  const [cod,      setCod]       = useState(false);
  const [loading,  setLoading]   = useState(false);

  const total = subtotal + shippingFee;
  const fmt   = (c: number) => `ETB ${(c / 100).toLocaleString('en-ET', { minimumFractionDigits: 2 })}`;

  const confirm = async () => {
    if (!fullName || !phone || !address) { addToast('error', 'Please fill all fields'); return; }
    setLoading(true);
    haptic.medium();
    setTimeout(() => {
      haptic.success();
      addToast('success', 'Order confirmed! Seller will contact you.');
      navigate('/orders');
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-bg pb-28">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-10 pb-4 border-b border-bg-border">
        <button onClick={() => navigate(-1)} className="text-blue text-sm">← Back</button>
        <h1 className="font-display text-lg font-bold text-ink">Checkout</h1>
      </div>

      <div className="px-4 py-5 space-y-5">
        {/* Shipping Address — matches Image 2 */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-bold text-ink">Shipping Address</p>
            <MapPin className="w-4 h-4 text-blue" />
          </div>
          <div className="bg-bg-card rounded-2xl border border-bg-border p-4 space-y-3">
            <div>
              <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-1.5">Full Name</p>
              <input value={fullName} onChange={(e) => setFullName(e.target.value)}
                placeholder="Enter recipient name"
                className="w-full px-4 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                           text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-1.5">City</p>
                <div className="relative">
                  <select value={city} onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                               text-ink focus:outline-none focus:border-blue/50 appearance-none">
                    {CITIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted pointer-events-none" />
                </div>
              </div>
              <div>
                <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-1.5">Phone</p>
                <input value={phone} onChange={(e) => setPhone(e.target.value)}
                  placeholder="+251..."
                  type="tel"
                  className="w-full px-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                             text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
              </div>
            </div>
            <div>
              <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-1.5">Specific Address</p>
              <input value={address} onChange={(e) => setAddress(e.target.value)}
                placeholder="Building, Office, House Number..."
                className="w-full px-4 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                           text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
            </div>
          </div>
        </div>

        {/* Payment Method — matches Image 2 */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-bold text-ink">Payment Method</p>
            <span className="text-2xs font-semibold text-blue uppercase tracking-wide">Select One</span>
          </div>
          <div className="grid grid-cols-4 gap-2 mb-2">
            {PAYMENT_METHODS.map((p) => (
              <button key={p.id} onClick={() => { setPayment(p.id); setCod(false); }}
                className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all
                  ${payment === p.id && !cod
                    ? 'bg-blue/10 border-blue shadow-blue'
                    : `${p.color} border`
                  }`}>
                <span className="text-xl">{p.emoji}</span>
                <span className="text-2xs font-semibold text-ink">{p.label}</span>
              </button>
            ))}
          </div>
          {/* Cash on delivery */}
          <button onClick={() => { setCod(!cod); setPayment(''); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border transition-all
              ${cod ? 'bg-blue/10 border-blue' : 'bg-bg-card border-bg-border'}`}>
            <div className="w-9 h-9 rounded-lg bg-bg-input flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-ink-secondary" />
            </div>
            <div className="flex-1 text-left">
              <p className="text-sm font-semibold text-ink">Cash on Delivery</p>
              <p className="text-2xs text-ink-secondary">Pay when you receive items</p>
            </div>
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center
              ${cod ? 'border-blue' : 'border-bg-border'}`}>
              {cod && <div className="w-2.5 h-2.5 rounded-full bg-blue" />}
            </div>
          </button>
        </div>

        {/* Order Summary — matches Image 2 */}
        <div>
          <p className="text-sm font-bold text-ink mb-3">Order Summary</p>
          <div className="bg-bg-card rounded-2xl border border-bg-border p-4 space-y-3">
            <div className="flex justify-between text-sm text-ink-secondary">
              <span>Subtotal</span>
              <span className="text-ink">{fmt(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm text-ink-secondary">
              <span>Shipping Fee</span>
              <span className="text-ink">{fmt(shippingFee)}</span>
            </div>
            <div className="border-t border-bg-border pt-3 flex justify-between items-center">
              <div>
                <p className="text-2xs font-semibold text-blue uppercase tracking-wide">Total Amount</p>
                <p className="text-2xl font-display font-bold text-ink mt-0.5">{fmt(total)}</p>
              </div>
              <span className="text-2xs font-bold text-ink-secondary bg-bg-input px-2.5 py-1 rounded-lg border border-bg-border">
                VAT INCLUDED
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm bar — matches Image 2 */}
      <div className="fixed bottom-0 left-0 right-0 bg-bg/95 backdrop-blur-md border-t border-bg-border
                      p-4 flex gap-3 safe-area-pb">
        <button onClick={() => navigate('/marketplace')}
          className="w-12 h-12 rounded-xl bg-bg-card border border-bg-border flex items-center justify-center">
          <ShoppingCart className="w-5 h-5 text-ink-secondary" />
        </button>
        <button onClick={confirm} disabled={loading}
          className="flex-1 py-3.5 rounded-2xl bg-blue font-bold text-white uppercase tracking-wider
                     text-sm shadow-blue flex items-center justify-center gap-2 disabled:opacity-60">
          <CheckCircle className="w-5 h-5" />
          {loading ? 'Processing...' : 'Confirm Order'}
        </button>
      </div>
    </div>
  );
};
