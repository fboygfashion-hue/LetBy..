export const AdminDashboard = () => <div className="p-4 font-display text-2xl font-bold text-ink">Admin — Phase 7</div>;
