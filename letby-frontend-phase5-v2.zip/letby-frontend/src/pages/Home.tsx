import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { useTelegram } from '@/hooks/useTelegram';
import { ProductCard } from '@/components/ui/ProductCard';
import { ProductCardSkeleton } from '@/components/ui/Skeleton';
import type { Listing, Category } from '@/types';

const CATEGORIES = ['All', 'Electronics', 'Fashion', 'Accessories', 'Vehicles', 'Furniture'];

export const Home = () => {
  useTelegram();
  const { user }   = useAuth();
  const navigate   = useNavigate();
  const [listings,   setListings]   = useState<Listing[]>([]);
  const [categories, setCategories] = useState<string[]>(CATEGORIES);
  const [active,     setActive]     = useState('All');
  const [search,     setSearch]     = useState('');
  const [loading,    setLoading]    = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await api.get<{ success: boolean; data: { data: Listing[] } }>(
          `/listings?limit=20${active !== 'All' ? `&category=${active.toLowerCase()}` : ''}`
        );
        setListings(data.data.data);
      } catch { /* silent */ } finally { setLoading(false); }
    };
    load();
  }, [active]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) navigate(`/marketplace?q=${encodeURIComponent(search)}`);
  };

  return (
    <div className="min-h-screen bg-bg">
      {/* Header */}
      <div className="px-4 pt-10 pb-4">
        <p className="font-display text-2xl font-bold text-ink">LetBy</p>
        <p className="text-xs text-ink-secondary mt-0.5">Ethiopia's Trusted Marketplace</p>

        {/* Search bar */}
        <form onSubmit={handleSearch} className="relative mt-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted" />
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Search items..."
            className="w-full pl-9 pr-4 py-2.5 bg-bg-input border border-bg-border rounded-xl
                       text-sm text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
        </form>
      </div>

      {/* Category pills — matches Image 3 */}
      <div className="flex gap-2 px-4 overflow-x-auto scrollbar-hide pb-3">
        {categories.map((cat) => (
          <button key={cat} onClick={() => setActive(cat)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-semibold transition-all
              ${active === cat
                ? 'bg-blue text-white shadow-blue'
                : 'bg-bg-card border border-bg-border text-ink-secondary'
              }`}>
            {cat}
          </button>
        ))}
      </div>

      {/* Product list — matches Image 3 exactly */}
      <div className="px-4 space-y-2.5">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <ProductCardSkeleton key={i} />)
          : listings.length > 0
            ? listings.map((l) => <ProductCard key={l.id} listing={l} />)
            : (
              <div className="flex flex-col items-center py-16 text-center">
                <span className="text-5xl mb-3">🔍</span>
                <p className="text-ink font-semibold">No listings yet</p>
                <p className="text-sm text-ink-secondary mt-1">Check back soon</p>
              </div>
            )
        }
      </div>
    </div>
  );
};
