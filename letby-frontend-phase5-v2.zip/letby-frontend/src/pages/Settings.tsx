import { useNavigate } from 'react-router-dom';
import { ShieldCheck, ChevronRight, LogOut, Package, Star, Bell, HelpCircle } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { haptic } from '@/lib/telegram';

export const Settings = () => {
  const { user, logout } = useAuthStore();
  const navigate         = useNavigate();
  const isSeller         = user?.role === 'SELLER';

  const handleLogout = () => { haptic.warning(); logout(); };

  const sections = [
    {
      title: 'Account',
      items: [
        { icon: Package, label: 'My Listings',  path: '/sell/products', show: isSeller },
        { icon: Star,    label: 'My Reviews',    path: '/reviews' },
        { icon: Bell,    label: 'Notifications', path: '/notifications' },
      ],
    },
    {
      title: 'Seller',
      items: [
        { icon: ShieldCheck, label: 'Get Verified', path: '/verify', show: !user?.sellerProfile?.isVerified },
      ],
    },
    {
      title: 'Support',
      items: [
        { icon: HelpCircle, label: 'Help & FAQ', path: '/help' },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-bg">
      <div className="px-4 pt-10 pb-4 border-b border-bg-border">
        <h1 className="font-display text-xl font-bold text-ink">Profile</h1>
      </div>

      {/* User card */}
      <div className="px-4 py-4">
        <div className="bg-bg-card rounded-2xl border border-bg-border p-4 flex items-center gap-3">
          {user?.photoUrl
            ? <img src={user.photoUrl} className="w-14 h-14 rounded-full object-cover" />
            : <div className="w-14 h-14 rounded-full bg-blue/20 flex items-center justify-center text-2xl">
                {user?.firstName?.[0] ?? '?'}
              </div>
          }
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-ink">{user?.firstName} {user?.lastName}</p>
            {user?.telegramUsername && (
              <p className="text-xs text-ink-secondary">@{user.telegramUsername}</p>
            )}
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-2xs font-bold px-2 py-0.5 rounded-full
                ${user?.sellerProfile?.isVerified
                  ? 'bg-verified-bg text-blue'
                  : 'bg-bg-input text-ink-muted'}`}>
                {user?.role === 'SELLER' ? (user.sellerProfile?.isVerified ? '✓ VERIFIED' : 'SELLER') : 'BUYER'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Menu sections */}
      <div className="px-4 space-y-4">
        {sections.map((section) => {
          const visible = section.items.filter((i) => i.show !== false);
          if (!visible.length) return null;
          return (
            <div key={section.title}>
              <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-widest mb-2 px-1">
                {section.title}
              </p>
              <div className="bg-bg-card rounded-2xl border border-bg-border divide-y divide-bg-border">
                {visible.map(({ icon: Icon, label, path }) => (
                  <button key={path} onClick={() => navigate(path)}
                    className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-bg-hover transition-colors">
                    <Icon className="w-4 h-4 text-ink-secondary flex-shrink-0" />
                    <span className="flex-1 text-sm text-ink text-left">{label}</span>
                    <ChevronRight className="w-4 h-4 text-ink-muted" />
                  </button>
                ))}
              </div>
            </div>
          );
        })}

        {/* Logout */}
        <button onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3.5 bg-risk-high/10 border border-risk-high/20
                     rounded-2xl text-risk-high">
          <LogOut className="w-4 h-4" />
          <span className="text-sm font-semibold">Log Out</span>
        </button>
      </div>
    </div>
  );
};
