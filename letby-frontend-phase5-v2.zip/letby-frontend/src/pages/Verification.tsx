import { useState, useRef } from 'react';
import { CreditCard, Camera, Phone, AtSign, ShieldCheck, Upload, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { useUIStore } from '@/store/ui.store';
import { haptic } from '@/lib/telegram';

export const Verification = () => {
  const navigate = useNavigate();
  const { addToast } = useUIStore();
  const idRef     = useRef<HTMLInputElement>(null);
  const selfieRef = useRef<HTMLInputElement>(null);

  const [idFile,     setIdFile]     = useState<File | null>(null);
  const [selfieFile, setSelfieFile] = useState<File | null>(null);
  const [idPreview,  setIdPreview]  = useState('');
  const [selPreview, setSelPreview] = useState('');
  const [phone,      setPhone]      = useState('');
  const [telegram,   setTelegram]   = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleFile = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (f: File) => void,
    preview: (s: string) => void
  ) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setter(f);
    const r = new FileReader();
    r.onload = (ev) => preview(ev.target?.result as string);
    r.readAsDataURL(f);
  };

  const handleSubmit = async () => {
    if (!idFile || !phone) { addToast('error', 'Please upload your ID and phone number'); return; }
    setSubmitting(true);
    haptic.medium();
    try {
      const fd = new FormData();
      fd.append('fullName', '');
      fd.append('phoneNumber', phone);
      fd.append('nationalId', idFile);
      if (selfieFile) fd.append('selfie', selfieFile);
      await api.post('/verification/submit', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      haptic.success();
      addToast('success', 'Verification submitted! We\'ll review within 24 hours.');
      navigate('/profile');
    } catch {
      haptic.error();
      addToast('error', 'Submission failed. Please try again.');
    } finally { setSubmitting(false); }
  };

  return (
    <div className="min-h-screen bg-bg pb-32">
      {/* Top bar */}
      <div className="px-4 pt-10 pb-4 border-b border-bg-border">
        <h1 className="font-display text-lg font-bold text-ink">Seller Verification</h1>
        <p className="text-xs text-ink-secondary mt-0.5">Complete to get verified and build buyer trust</p>
      </div>

      <div className="px-4 py-5 space-y-4">
        {/* IDENTIFICATION section */}
        <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-widest flex items-center justify-between">
          Identification
          <button className="text-blue text-2xs">ⓘ</button>
        </p>

        {/* National ID */}
        <div className="bg-bg-card rounded-2xl border border-bg-border overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-3 border-b border-bg-border">
            <div className="w-9 h-9 rounded-lg bg-blue/10 flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-blue" />
            </div>
            <div>
              <p className="text-sm font-semibold text-ink">National ID photo</p>
              <p className="text-2xs text-ink-secondary">Upload the front side of your ID</p>
            </div>
          </div>
          <button onClick={() => idRef.current?.click()}
            className="w-full px-4 py-8 flex flex-col items-center gap-2 bg-bg-input
                       border-2 border-dashed border-bg-border hover:border-blue/40 transition-colors m-3 rounded-xl"
            style={{ width: 'calc(100% - 24px)' }}>
            {idPreview
              ? <img src={idPreview} className="w-full h-32 object-cover rounded-lg" />
              : <>
                  <Upload className="w-6 h-6 text-blue" />
                  <span className="text-sm font-medium text-ink-secondary">Tap to upload</span>
                </>
            }
          </button>
          <input ref={idRef} type="file" accept="image/*" className="hidden"
            onChange={(e) => handleFile(e, setIdFile, setIdPreview)} />
        </div>

        {/* Selfie with ID */}
        <div className="bg-bg-card rounded-2xl border border-bg-border overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-3 border-b border-bg-border">
            <div className="w-9 h-9 rounded-lg bg-blue/10 flex items-center justify-center">
              <Camera className="w-4 h-4 text-blue" />
            </div>
            <div>
              <p className="text-sm font-semibold text-ink">Selfie with ID</p>
              <p className="text-2xs text-ink-secondary">Ensure your face and ID are visible</p>
            </div>
          </div>
          <button onClick={() => selfieRef.current?.click()}
            className="w-full px-4 py-8 flex flex-col items-center gap-2 bg-bg-input
                       border-2 border-dashed border-bg-border hover:border-blue/40 transition-colors m-3 rounded-xl"
            style={{ width: 'calc(100% - 24px)' }}>
            {selPreview
              ? <img src={selPreview} className="w-full h-32 object-cover rounded-lg" />
              : <>
                  <Camera className="w-6 h-6 text-blue" />
                  <span className="text-sm font-medium text-ink-secondary">Capture photo</span>
                </>
            }
          </button>
          <input ref={selfieRef} type="file" accept="image/*" capture="user" className="hidden"
            onChange={(e) => handleFile(e, setSelfieFile, setSelPreview)} />
        </div>

        {/* Contact Details — matches Image 1 */}
        <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-widest mt-6">Contact Details</p>

        <div className="space-y-3">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Phone className="w-3.5 h-3.5 text-ink-secondary" />
              <span className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide">Phone Number</span>
            </div>
            <input value={phone} onChange={(e) => setPhone(e.target.value)}
              placeholder="+251 (___) ___-____"
              type="tel"
              className="w-full px-4 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                         text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <AtSign className="w-3.5 h-3.5 text-ink-secondary" />
              <span className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide">Telegram Username</span>
            </div>
            <input value={telegram} onChange={(e) => setTelegram(e.target.value)}
              placeholder="@yourusername"
              className="w-full px-4 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                         text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
          </div>
        </div>

        {/* Privacy note */}
        <div className="flex items-start gap-3 bg-bg-card border border-bg-border rounded-xl p-4">
          <ShieldCheck className="w-4 h-4 text-blue flex-shrink-0 mt-0.5" />
          <p className="text-2xs text-ink-secondary leading-relaxed">
            Your data is encrypted and only used for identity verification purposes.
            We never share your personal information with third parties.
          </p>
        </div>
      </div>

      {/* Submit button — matches Image 1 */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-bg/95 backdrop-blur-md border-t border-bg-border safe-area-pb">
        <button onClick={handleSubmit} disabled={submitting}
          className="w-full py-4 rounded-2xl bg-blue text-white font-bold text-base
                     shadow-blue flex items-center justify-center gap-2 disabled:opacity-60">
          <CheckCircle className="w-5 h-5" />
          {submitting ? 'Submitting...' : 'Submit Verification'}
        </button>
      </div>
    </div>
  );
};
