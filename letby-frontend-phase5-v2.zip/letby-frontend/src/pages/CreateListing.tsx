import { useState, useRef } from 'react';
import { Camera, X, ChevronDown, AlertCircle, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { useUIStore } from '@/store/ui.store';
import { haptic } from '@/lib/telegram';

const CATEGORIES = ['Electronics', 'Phones', 'Laptops', 'Fashion', 'Furniture', 'Vehicles', 'Appliances', 'Books', 'Sports', 'Other'];
const CONDITIONS = [
  { value: 'NEW',            label: 'New' },
  { value: 'USED_EXCELLENT', label: 'Used — Excellent' },
  { value: 'USED_GOOD',      label: 'Used — Good' },
  { value: 'USED_FAIR',      label: 'Used — Fair' },
];

export const CreateListing = () => {
  const navigate = useNavigate();
  const { addToast } = useUIStore();
  const fileRef = useRef<HTMLInputElement>(null);

  const [images,      setImages]      = useState<File[]>([]);
  const [previews,    setPreviews]    = useState<string[]>([]);
  const [title,       setTitle]       = useState('');
  const [price,       setPrice]       = useState('');
  const [minPrice,    setMinPrice]    = useState('');
  const [category,    setCategory]    = useState('Electronics');
  const [condition,   setCondition]   = useState('NEW');
  const [description, setDescription] = useState('');
  const [stock,       setStock]       = useState('0');
  const [submitting,  setSubmitting]  = useState(false);
  const [error,       setError]       = useState('');

  const handleImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []).slice(0, 5 - images.length);
    setImages((p) => [...p, ...files]);
    files.forEach((f) => {
      const r = new FileReader();
      r.onload = (ev) => setPreviews((p) => [...p, ev.target?.result as string]);
      r.readAsDataURL(f);
    });
  };

  const removeImage = (i: number) => {
    setImages((p) => p.filter((_, idx) => idx !== i));
    setPreviews((p) => p.filter((_, idx) => idx !== i));
  };

  const handleSubmit = async () => {
    if (!price || parseFloat(price) <= 0) { setError('Please provide a price for your product'); return; }
    if (!title.trim()) { setError('Please add a product title'); return; }
    setError('');
    setSubmitting(true);
    haptic.medium();
    try {
      const fd = new FormData();
      fd.append('title', title);
      fd.append('price', String(Math.round(parseFloat(price) * 100)));
      fd.append('categorySlug', category.toLowerCase());
      fd.append('condition', condition);
      fd.append('description', description);
      fd.append('isNegotiable', minPrice ? 'true' : 'false');
      fd.append('location', 'Addis Ababa');
      images.forEach((f) => fd.append('images', f));
      await api.post('/listings', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      haptic.success();
      addToast('success', 'Product listed successfully!');
      navigate('/sell/products');
    } catch {
      haptic.error();
      addToast('error', 'Failed to create listing');
    } finally { setSubmitting(false); }
  };

  return (
    <div className="min-h-screen bg-bg">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-10 pb-4 border-b border-bg-border">
        <button onClick={() => navigate(-1)} className="text-blue text-sm font-medium">← Back</button>
        <h1 className="font-display text-lg font-bold text-ink">Add Product</h1>
        <div className="ml-auto text-xs text-ink-secondary font-mono">{images.length} / 5</div>
      </div>

      <div className="px-4 py-5 space-y-5">
        {/* Product Media — matches Images 9 & 10 */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-ink tracking-wide uppercase">Product Media</p>
            <p className="text-xs text-ink-secondary font-mono">{images.length} / 5</p>
          </div>
          <div className="flex gap-3">
            {/* Upload button */}
            {images.length < 5 && (
              <button onClick={() => fileRef.current?.click()}
                className="w-[90px] h-[90px] rounded-xl border-2 border-dashed border-bg-border
                           bg-bg-input flex flex-col items-center justify-center gap-1 flex-shrink-0">
                <Camera className="w-5 h-5 text-blue" />
                <span className="text-2xs text-ink-secondary font-semibold uppercase tracking-wide">
                  {images.length === 0 ? 'Upload' : 'Add Photo'}
                </span>
              </button>
            )}
            {/* Image previews */}
            {previews.map((src, i) => (
              <div key={i} className="relative flex-shrink-0">
                <img src={src} className="w-[90px] h-[90px] rounded-xl object-cover" />
                <button onClick={() => removeImage(i)}
                  className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-risk-high rounded-full
                             flex items-center justify-center shadow-card">
                  <X className="w-3 h-3 text-white" />
                </button>
              </div>
            ))}
          </div>
          {images.length === 0 && (
            <p className="text-2xs text-ink-muted mt-2">
              Drag and drop to reorder images. First image will be used as the cover.
            </p>
          )}
          <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImages} />
        </div>

        {/* Form section */}
        <div className="bg-bg-card rounded-2xl p-4 border border-bg-border space-y-4">
          {/* Title */}
          <div>
            <label className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-2 block">
              Product Title
            </label>
            <div className="relative">
              <input value={title} onChange={(e) => setTitle(e.target.value.slice(0, 60))}
                placeholder="Enter product name"
                className="w-full px-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                           text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-2xs text-ink-muted">
                {title.length}/60
              </span>
            </div>
          </div>

          {/* Price + Category */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-2 block">Price</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-etb">ETB</span>
                <input type="number" value={price} onChange={(e) => setPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-10 pr-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                             text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
              </div>
            </div>
            <div>
              <label className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-2 block">Category</label>
              <div className="relative">
                <select value={category} onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                             text-ink focus:outline-none focus:border-blue/50 appearance-none">
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Stock + Min Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-2 block">Stock Quantity</label>
              <input type="number" value={stock} onChange={(e) => setStock(e.target.value)}
                className="w-full px-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                           text-ink focus:outline-none focus:border-blue/50" />
            </div>
            <div>
              <label className="text-2xs font-semibold text-ink-secondary uppercase tracking-wide mb-2 block">Minimum Price</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-etb">ETB</span>
                <input type="number" value={minPrice} onChange={(e) => setMinPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-10 pr-3 py-3 bg-bg-input border border-bg-border rounded-xl text-sm
                             text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50" />
              </div>
            </div>
          </div>
        </div>

        {/* Description */}
        <div>
          <p className="text-sm font-semibold text-ink mb-2">Description</p>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder="Tell buyers more about your item..."
            rows={4}
            className="w-full px-4 py-3 bg-bg-card border border-bg-border rounded-2xl text-sm
                       text-ink placeholder-ink-muted focus:outline-none focus:border-blue/50 resize-none" />
        </div>

        {/* Condition */}
        <div>
          <p className="text-xs font-semibold text-ink-secondary uppercase tracking-wide mb-2">Condition</p>
          <div className="grid grid-cols-2 gap-2">
            {CONDITIONS.map((c) => (
              <button key={c.value} onClick={() => setCondition(c.value)}
                className={`py-2.5 rounded-xl text-sm font-medium border transition-all
                  ${condition === c.value
                    ? 'bg-blue/10 border-blue text-blue'
                    : 'bg-bg-input border-bg-border text-ink-secondary'
                  }`}>
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center gap-2 text-risk-high text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}
      </div>

      {/* Bottom action bar — matches Image 9 */}
      <div className="sticky bottom-0 bg-bg/95 backdrop-blur-md border-t border-bg-border p-4 flex gap-3 safe-area-pb">
        <button onClick={() => navigate(-1)}
          className="flex-1 py-3 rounded-xl border border-bg-border text-risk-high font-semibold
                     flex items-center justify-center gap-2 text-sm">
          <X className="w-4 h-4" />
          Discard
        </button>
        <button onClick={handleSubmit} disabled={submitting}
          className="flex-1 py-3 rounded-xl bg-blue font-semibold text-white shadow-blue
                     flex items-center justify-center gap-2 text-sm disabled:opacity-60">
          <CheckCircle className="w-4 h-4" />
          {submitting ? 'Saving...' : 'Save Product'}
        </button>
      </div>
    </div>
  );
};
