export const SellerProfile = () => <div className="p-4 font-display text-2xl font-bold text-ink">Seller Profile — Phase 6</div>;
