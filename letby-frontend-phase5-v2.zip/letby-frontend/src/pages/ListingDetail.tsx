// Filled in Phase 6 — Listings & Reviews
export const ListingDetail = () => <div className="p-4 font-display text-2xl font-bold text-ink">Listing Detail — Phase 6</div>;
