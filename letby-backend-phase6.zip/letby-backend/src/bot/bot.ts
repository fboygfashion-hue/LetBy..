import TelegramBot from 'node-telegram-bot-api';
import { env } from '../config/env';
import { redis, cache } from '../config/redis';
import { searchHandler } from './handlers/search.handler';
import { listingHandler } from './handlers/listing.handler';
import { negotiationHandler } from './handlers/negotiation.handler';
import { reviewHandler } from './handlers/review.handler';

const bot = new TelegramBot(env.TELEGRAM_BOT_TOKEN, { polling: true });

// ─────────────────────────────────────────
// START & HELP
// ─────────────────────────────────────────

bot.onText(/^\/start$/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;

  await bot.sendMessage(chatId, `Welcome to LetBy AI Assistant.

Trusted marketplace. Verified sellers. Faster deals.

What are you looking for today?

Examples:
• iPhone 13
• Gaming laptop
• Sneakers
• Furniture
• Cars
• Apartments

Type product name + budget if possible.`, {
    reply_markup: {
      inline_keyboard: [[
        { text: '🏠 Browse Home', callback_data: 'home' },
        { text: '💬 Help', callback_data: 'help' },
      ]],
    },
  });

  // Initialize user session
  await cache.set(`telegram:${chatId}:state`, 'home', 86400);
});

bot.onText(/^\/help$/, async (msg) => {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId, `*LetBy Bot Commands*

/start — Start shopping
/help — Show this message

*How to use:*
1. Type a product name (e.g., "Gaming Laptop")
2. Select a listing by number
3. View photos, reviews, trust score
4. Contact seller or negotiate price
5. Pay and get items delivered

*Available cities:*
Addis Ababa, Dire Dawa, Mekelle, Gondar, Hawassa`, {
    parse_mode: 'Markdown',
  });
});

// ─────────────────────────────────────────
// MESSAGE HANDLER (Search flow)
// ─────────────────────────────────────────

bot.on('message', async (msg) => {
  if (msg.text?.startsWith('/')) return; // Skip commands
  if (!msg.text) return;

  const chatId = msg.chat.id;
  const text = msg.text.trim();

  try {
    const state = await cache.get<string>(`telegram:${chatId}:state`);

    if (state === 'negotiation') {
      await negotiationHandler.handleOffer(bot, chatId, text);
    } else if (state === 'home' || !state) {
      // Search mode
      await searchHandler.search(bot, chatId, text);
    }
  } catch (err) {
    console.error('Bot message error:', err);
    await bot.sendMessage(chatId, '❌ Something went wrong. Try again with /start');
  }
});

// ─────────────────────────────────────────
// CALLBACK QUERIES (Inline buttons)
// ─────────────────────────────────────────

bot.on('callback_query', async (query) => {
  const chatId = query.message!.chat.id;
  const data = query.data!;
  const msgId = query.message!.message_id;

  try {
    if (data.startsWith('listing:')) {
      const listingId = data.split(':')[1];
      await listingHandler.show(bot, chatId, listingId, msgId);
    } else if (data.startsWith('review:')) {
      const listingId = data.split(':')[1];
      await reviewHandler.show(bot, chatId, listingId, msgId);
    } else if (data === 'negotiate') {
      await negotiationHandler.start(bot, chatId, msgId);
    } else if (data === 'contact_seller') {
      await listingHandler.contactSeller(bot, chatId, msgId);
    } else if (data === 'request_video') {
      await listingHandler.requestVideo(bot, chatId, msgId);
    } else if (data === 'reserve') {
      await listingHandler.reserve(bot, chatId, msgId);
    } else if (data === 'home') {
      await bot.editMessageText(
        'Welcome to LetBy AI Assistant.\n\nTrusted marketplace. Verified sellers. Faster deals.\n\nWhat are you looking for today?',
        { chat_id: chatId, message_id: msgId },
      );
      await cache.set(`telegram:${chatId}:state`, 'home', 86400);
    }

    await bot.answerCallbackQuery(query.id);
  } catch (err) {
    console.error('Callback error:', err);
    await bot.answerCallbackQuery(query.id, { text: 'Error processing request' });
  }
});

// ─────────────────────────────────────────
// GRACEFUL SHUTDOWN
// ─────────────────────────────────────────

process.on('SIGINT', async () => {
  console.log('Bot shutting down...');
  bot.stopPolling();
  await redis.disconnect();
  process.exit(0);
});

export { bot };
