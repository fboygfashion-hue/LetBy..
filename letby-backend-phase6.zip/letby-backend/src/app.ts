import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env';
import { errorMiddleware } from './middleware/error.middleware';
import { globalLimiter } from './middleware/rateLimit.middleware';
import authRoutes from './modules/auth/auth.routes';
import './bot/bot'; // Initialize bot on startup

const app = express();

app.use(helmet());
app.use(cors({
  origin: env.ALLOWED_ORIGINS.split(',').map((o) => o.trim()),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
}));

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

if (env.NODE_ENV !== 'test') {
  app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

app.use(globalLimiter);

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', env: env.NODE_ENV, bot: '🤖 Running' });
});

// ─── Routes ───────────────────────────────
app.use('/api/auth', authRoutes);
// Phase 5+:
// app.use('/api/listings', listingRoutes);
// ──────────────────────────────────────────

app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'NOT_FOUND' });
});

app.use(errorMiddleware);

const start = async () => {
  try {
    const { redis } = await import('./config/redis');
    await redis.connect();
    console.log('✅ Redis connected');

    app.listen(env.PORT, () => {
      console.log(`🚀 LetBy API running on port ${env.PORT} [${env.NODE_ENV}]`);
      console.log(`🤖 Telegram Bot polling...`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
};

start();

export default app;
