const axios = require('axios');

const chapaClient = axios.create({
  baseURL: process.env.CHAPA_BASE_URL,
  headers: {
    'Authorization': `Bearer ${process.env.CHAPA_SECRET_KEY}`,
    'Content-Type': 'application/json'
  }
});

const initiatePayment = async ({ orderId, amount, buyerEmail, buyerName, phone, callbackUrl, returnUrl }) => {
  const txRef = `LETBY-${orderId}-${Date.now()}`;
  
  const payload = {
    amount: amount.toString(),
    currency: 'ETB',
    email: buyerEmail || 'buyer@letby.com',
    first_name: buyerName || 'LetBy',
    last_name: 'Buyer',
    phone_number: phone || '0900000000',
    tx_ref: txRef,
    callback_url: callbackUrl,
    return_url: returnUrl || 'https://t.me/LetByCommerceBot',
    customization: {
      title: 'LetBy Commerce',
      description: `Payment for Order ${orderId}`
    }
  };

  const response = await chapaClient.post('/transaction/initialize', payload);
  return {
    checkoutUrl: response.data.data.checkout_url,
    txRef
  };
};

const verifyPayment = async (txRef) => {
  const response = await chapaClient.get(`/transaction/verify/${txRef}`);
  return response.data;
};

module.exports = { initiatePayment, verifyPayment };
