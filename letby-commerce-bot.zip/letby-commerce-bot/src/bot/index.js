const { Telegraf } = require('telegraf');
const buyerHandlers = require('./handlers/buyer');
const sellerHandlers = require('./handlers/seller');
const Order = require('../models/Order');

const createBot = () => {
  const bot = new Telegraf(process.env.BOT_TOKEN);

  // ── /start ──────────────────────────────────────────────────────────
  bot.start(async (ctx) => {
    await buyerHandlers.showMainMenu(ctx);
  });

  // ── Main Menu Buttons ───────────────────────────────────────────────
  bot.hears('🔍 Browse Products', async (ctx) => {
    await buyerHandlers.browseCategories(ctx);
  });

  bot.hears('🛒 My Cart', async (ctx) => {
    await buyerHandlers.viewCart(ctx);
  });

  bot.hears('📦 My Orders', async (ctx) => {
    await buyerHandlers.myOrders(ctx);
  });

  bot.hears('🏪 Become a Seller', async (ctx) => {
    await sellerHandlers.startSellerRegistration(ctx);
  });

  bot.hears('📞 Support', async (ctx) => {
    await ctx.reply(
      '📞 *LetBy Support*\n\nFor help, contact us:\n@LetBySupport\n\nOr email: support@letby.com',
      { parse_mode: 'Markdown' }
    );
  });

  bot.hears('🔎 Search', async (ctx) => {
    await ctx.reply('🔍 Type what you want to search:');
    // handled in text handler below
  });

  // ── Inline Callback Buttons ─────────────────────────────────────────
  
  // Browse categories
  bot.action('browse', async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.browseCategories(ctx);
  });

  bot.action('main_menu', async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.showMainMenu(ctx);
  });

  // Category selection
  bot.action(/^cat_(.+)_page_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const [, category, page] = ctx.match;
    await buyerHandlers.showProductsByCategory(ctx, category, parseInt(page));
  });

  bot.action(/^cat_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.showProductsByCategory(ctx, ctx.match[1]);
  });

  // Product detail
  bot.action(/^product_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.showProductDetail(ctx, ctx.match[1]);
  });

  // Add to cart
  bot.action(/^addcart_(.+)$/, async (ctx) => {
    await buyerHandlers.addToCart(ctx, ctx.match[1]);
  });

  // Cart
  bot.action('view_cart', async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.viewCart(ctx);
  });

  bot.action('clear_cart', async (ctx) => {
    const user = await buyerHandlers.getOrCreateUser(ctx);
    user.cart = [];
    await user.save();
    await ctx.answerCbQuery('Cart cleared!');
    await ctx.reply('Cart cleared. 🛍 Keep shopping!');
  });

  // Checkout
  bot.action('checkout', async (ctx) => {
    await ctx.answerCbQuery();
    await buyerHandlers.checkout(ctx);
  });

  // Payment confirmation
  bot.action(/^confirm_payment_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const order = await Order.findById(ctx.match[1]);
    if (!order) return ctx.reply('Order not found.');

    await ctx.reply(
      `⏳ Verifying payment for *${order.orderId}*...\n\nIf payment confirmed, we'll notify you and the seller.`,
      { parse_mode: 'Markdown' }
    );

    // In production: verify via Chapa API here
    // For now, mark as paid manually
    order.status = 'paid';
    order.payment.status = 'success';
    order.payment.paidAt = new Date();
    order.timeline.push({ status: 'paid', message: 'Payment confirmed' });
    await order.save();

    // Notify seller via bot
    try {
      await bot.telegram.sendMessage(
        order.sellerTelegramId,
        `💰 *New Order Paid!*\n\nOrder: ${order.orderId}\nProduct: ${order.product.name}\nAmount: ${order.total} ETB\n\nContact buyer to arrange delivery.`,
        { parse_mode: 'Markdown' }
      );
    } catch (e) { /* seller may have blocked bot */ }

    await ctx.reply(`✅ *Payment Recorded!*\n\nOrder: ${order.orderId}\nThe seller has been notified.`, { parse_mode: 'Markdown' });
  });

  // Cancel order
  bot.action(/^cancel_order_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const order = await Order.findById(ctx.match[1]);
    if (!order) return;
    order.status = 'cancelled';
    order.timeline.push({ status: 'cancelled', message: 'Cancelled by buyer' });
    await order.save();
    await ctx.reply(`❌ Order ${order.orderId} cancelled.`);
  });

  // Seller actions
  bot.action('list_product', async (ctx) => {
    await ctx.answerCbQuery();
    await sellerHandlers.startProductListing(ctx);
  });

  bot.action('seller_dashboard', async (ctx) => {
    await ctx.answerCbQuery();
    await sellerHandlers.showSellerDashboard(ctx);
  });

  bot.action('seller_orders', async (ctx) => {
    await ctx.answerCbQuery();
    await sellerHandlers.sellerOrders(ctx);
  });

  // Product category selection during listing
  bot.action(/^pcat_(.+)$/, async (ctx) => {
    await sellerHandlers.setProductCategory(ctx, ctx.match[1]);
  });

  // Seller order management
  bot.action(/^confirm_order_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const order = await Order.findByIdAndUpdate(ctx.match[1], {
      status: 'confirmed',
      $push: { timeline: { status: 'confirmed', message: 'Confirmed by seller' } }
    }, { new: true });
    await ctx.reply(`✅ Order ${order.orderId} confirmed!`);

    // Notify buyer
    try {
      await bot.telegram.sendMessage(order.buyerTelegramId, `✅ Your order *${order.orderId}* has been confirmed by the seller!`, { parse_mode: 'Markdown' });
    } catch (e) {}
  });

  bot.action(/^ship_order_(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const order = await Order.findByIdAndUpdate(ctx.match[1], {
      status: 'shipped',
      $push: { timeline: { status: 'shipped', message: 'Marked as shipped by seller' } }
    }, { new: true });
    await ctx.reply(`🚚 Order ${order.orderId} marked as shipped!`);

    try {
      await bot.telegram.sendMessage(order.buyerTelegramId, `🚚 Your order *${order.orderId}* has been shipped! Expect delivery soon.`, { parse_mode: 'Markdown' });
    } catch (e) {}
  });

  // ── Text Messages ───────────────────────────────────────────────────
  bot.on('text', async (ctx) => {
    const userId = String(ctx.from.id);
    const text = ctx.message.text;

    // Skip commands and keyboard buttons
    if (text.startsWith('/')) return;

    // Check seller registration session
    if (sellerHandlers.isInSellerSession(userId)) {
      return sellerHandlers.handleSellerRegistration(ctx);
    }

    // Check product listing session
    if (sellerHandlers.isInProductSession(userId)) {
      return sellerHandlers.handleProductListing(ctx);
    }

    // Default: treat as search
    if (text.length > 1) {
      await buyerHandlers.handleSearch(ctx, text);
    }
  });

  // ── Photos (for product listing) ────────────────────────────────────
  bot.on('photo', async (ctx) => {
    const userId = String(ctx.from.id);
    if (sellerHandlers.isInProductSession(userId)) {
      await sellerHandlers.handleProductListing(ctx);
    }
  });

  return bot;
};

module.exports = createBot;
