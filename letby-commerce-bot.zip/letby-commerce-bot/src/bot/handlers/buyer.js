const { Markup } = require('telegraf');
const User = require('../../models/User');
const Product = require('../../models/Product');
const Order = require('../../models/Order');
const { initiatePayment } = require('../../services/payment');

// ── Register or get buyer ──────────────────────────────────────────────
const getOrCreateUser = async (ctx) => {
  const tgUser = ctx.from;
  let user = await User.findOne({ telegramId: String(tgUser.id) });
  if (!user) {
    user = await User.create({
      telegramId: String(tgUser.id),
      username: tgUser.username,
      firstName: tgUser.first_name,
      lastName: tgUser.last_name
    });
  }
  return user;
};

// ── Main Menu ─────────────────────────────────────────────────────────
const showMainMenu = async (ctx) => {
  await ctx.reply(
    `🛍 *Welcome to LetBy Commerce*\nEthiopia's Telegram Marketplace`,
    {
      parse_mode: 'Markdown',
      ...Markup.keyboard([
        ['🔍 Browse Products', '🔎 Search'],
        ['🛒 My Cart', '📦 My Orders'],
        ['🏪 Become a Seller', '📞 Support']
      ]).resize()
    }
  );
};

// ── Browse Categories ─────────────────────────────────────────────────
const browseCategories = async (ctx) => {
  const categories = ['Electronics', 'Fashion', 'Food', 'Beauty', 'Home', 'Books', 'Sports', 'Other'];
  
  const buttons = categories.map(cat => [Markup.button.callback(`📂 ${cat}`, `cat_${cat}`)]);
  buttons.push([Markup.button.callback('🔙 Back to Menu', 'main_menu')]);

  await ctx.reply('Choose a category:', Markup.inlineKeyboard(buttons));
};

// ── Products by Category ──────────────────────────────────────────────
const showProductsByCategory = async (ctx, category, page = 0) => {
  const limit = 5;
  const products = await Product.find({ category, isActive: true, stock: { $gt: 0 } })
    .skip(page * limit)
    .limit(limit);

  if (!products.length) {
    return ctx.reply('No products in this category yet.');
  }

  for (const product of products) {
    const caption = `*${product.name}*\n💰 ${product.price} ETB\n📍 ${product.location || 'Ethiopia'}\n\n${product.description.slice(0, 100)}...`;
    
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback('👁 View Details', `product_${product._id}`)],
      [Markup.button.callback('🛒 Add to Cart', `addcart_${product._id}`)]
    ]);

    if (product.images && product.images.length > 0) {
      await ctx.replyWithPhoto(product.images[0], { caption, parse_mode: 'Markdown', ...buttons });
    } else {
      await ctx.reply(caption, { parse_mode: 'Markdown', ...buttons });
    }
  }

  // Pagination
  const total = await Product.countDocuments({ category, isActive: true });
  if ((page + 1) * limit < total) {
    await ctx.reply('Load more:', Markup.inlineKeyboard([
      [Markup.button.callback('⬇️ Load More', `cat_${category}_page_${page + 1}`)]
    ]));
  }
};

// ── Product Detail ────────────────────────────────────────────────────
const showProductDetail = async (ctx, productId) => {
  const product = await Product.findById(productId).populate('sellerId', 'storeName rating');
  if (!product) return ctx.reply('Product not found.');

  // Increment views
  product.views += 1;
  await product.save();

  const text = `*${product.name}*\n\n` +
    `💰 Price: *${product.price} ETB*\n` +
    `🏪 Seller: ${product.sellerId?.storeName || 'LetBy Seller'}\n` +
    `📦 Stock: ${product.stock} available\n` +
    `🚚 Delivery: ${product.deliveryAvailable ? `Yes (+${product.deliveryFee} ETB)` : 'Pickup only'}\n` +
    `📍 Location: ${product.location || 'Not specified'}\n\n` +
    `📝 *Description:*\n${product.description}`;

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('🛒 Add to Cart', `addcart_${productId}`)],
    [Markup.button.callback('⚡ Buy Now', `buynow_${productId}`)],
    [Markup.button.callback('🔙 Back', 'browse')]
  ]);

  if (product.images && product.images.length > 0) {
    await ctx.replyWithPhoto(product.images[0], { caption: text, parse_mode: 'Markdown', ...buttons });
  } else {
    await ctx.reply(text, { parse_mode: 'Markdown', ...buttons });
  }
};

// ── Add to Cart ───────────────────────────────────────────────────────
const addToCart = async (ctx, productId) => {
  const user = await getOrCreateUser(ctx);
  const product = await Product.findById(productId);
  if (!product || !product.isActive) return ctx.answerCbQuery('Product unavailable');

  const existingItem = user.cart.find(item => item.productId.toString() === productId);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    user.cart.push({ productId, quantity: 1 });
  }
  await user.save();

  await ctx.answerCbQuery(`✅ "${product.name}" added to cart!`);
  await ctx.reply(`🛒 Added to cart!\n*${product.name}* — ${product.price} ETB`, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🛒 View Cart', 'view_cart')],
      [Markup.button.callback('🔄 Continue Shopping', 'browse')]
    ])
  });
};

// ── View Cart ─────────────────────────────────────────────────────────
const viewCart = async (ctx) => {
  const user = await getOrCreateUser(ctx);
  
  if (!user.cart.length) {
    return ctx.reply('Your cart is empty. Start browsing!', Markup.inlineKeyboard([
      [Markup.button.callback('🛍 Browse Products', 'browse')]
    ]));
  }

  await user.populate('cart.productId');
  
  let total = 0;
  let cartText = '🛒 *Your Cart:*\n\n';
  
  for (const item of user.cart) {
    const product = item.productId;
    if (!product) continue;
    const itemTotal = product.price * item.quantity;
    total += itemTotal;
    cartText += `• *${product.name}*\n  ${item.quantity}x ${product.price} ETB = *${itemTotal} ETB*\n\n`;
  }

  cartText += `─────────────\n💰 *Total: ${total} ETB*`;

  await ctx.reply(cartText, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💳 Checkout', 'checkout')],
      [Markup.button.callback('🗑 Clear Cart', 'clear_cart')],
      [Markup.button.callback('🔄 Continue Shopping', 'browse')]
    ])
  });
};

// ── Checkout ──────────────────────────────────────────────────────────
const checkout = async (ctx) => {
  const user = await getOrCreateUser(ctx);
  await user.populate('cart.productId');

  if (!user.cart.length) return ctx.reply('Cart is empty.');

  // Group by seller (one order per seller)
  const sellerGroups = {};
  for (const item of user.cart) {
    const product = item.productId;
    if (!product) continue;
    const sid = product.sellerTelegramId;
    if (!sellerGroups[sid]) sellerGroups[sid] = { seller: product.sellerId, sellerTelegramId: sid, items: [] };
    sellerGroups[sid].items.push(item);
  }

  for (const [sellerTgId, group] of Object.entries(sellerGroups)) {
    let subtotal = 0;
    let orderItems = [];

    for (const item of group.items) {
      const product = item.productId;
      subtotal += product.price * item.quantity;
      orderItems.push({ productId: product._id, name: product.name, price: product.price, quantity: item.quantity });
    }

    const commission = subtotal * (parseFloat(process.env.COMMISSION_PERCENT) / 100);
    const total = subtotal;

    const order = await Order.create({
      buyerId: user._id,
      buyerTelegramId: String(ctx.from.id),
      sellerId: group.seller,
      sellerTelegramId: sellerTgId,
      product: orderItems[0], // simplified: first product
      subtotal,
      commission,
      total,
      timeline: [{ status: 'pending', message: 'Order placed' }]
    });

    // Generate Chapa payment link
    try {
      const { checkoutUrl, txRef } = await initiatePayment({
        orderId: order.orderId,
        amount: total,
        buyerName: user.firstName,
        callbackUrl: `${process.env.WEBHOOK_URL}/payment/callback`
      });

      order.payment.chapaRef = txRef;
      order.payment.method = 'chapa';
      await order.save();

      await ctx.reply(
        `📋 *Order Created!*\n\nOrder ID: \`${order.orderId}\`\nTotal: *${total} ETB*\n\nPay now with Telebirr, MPSA, or Bank:`,
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.url('💳 Pay Now', checkoutUrl)],
            [Markup.button.callback('✅ I Paid', `confirm_payment_${order._id}`)],
            [Markup.button.callback('❌ Cancel Order', `cancel_order_${order._id}`)]
          ])
        }
      );
    } catch (err) {
      await ctx.reply(`Order created (ID: ${order.orderId}). Contact support for payment.`);
    }
  }

  // Clear cart after checkout
  user.cart = [];
  await user.save();
};

// ── My Orders ─────────────────────────────────────────────────────────
const myOrders = async (ctx) => {
  const user = await getOrCreateUser(ctx);
  const orders = await Order.find({ buyerTelegramId: String(ctx.from.id) })
    .sort({ createdAt: -1 })
    .limit(10);

  if (!orders.length) {
    return ctx.reply('No orders yet. Start shopping!');
  }

  let text = '📦 *Your Orders:*\n\n';
  const statusEmoji = {
    pending: '⏳', paid: '✅', confirmed: '👍',
    shipped: '🚚', delivered: '✅', cancelled: '❌', refunded: '↩️'
  };

  for (const order of orders) {
    text += `${statusEmoji[order.status] || '📦'} *${order.orderId}*\n`;
    text += `   ${order.product.name} — ${order.total} ETB\n`;
    text += `   Status: ${order.status.toUpperCase()}\n\n`;
  }

  await ctx.reply(text, { parse_mode: 'Markdown' });
};

// ── Search ────────────────────────────────────────────────────────────
const handleSearch = async (ctx, query) => {
  const products = await Product.find({
    $text: { $search: query },
    isActive: true,
    stock: { $gt: 0 }
  }).limit(5);

  if (!products.length) return ctx.reply('No products found. Try a different keyword.');

  for (const product of products) {
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback('👁 View', `product_${product._id}`)],
      [Markup.button.callback('🛒 Add to Cart', `addcart_${product._id}`)]
    ]);
    await ctx.reply(
      `*${product.name}*\n💰 ${product.price} ETB\n${product.description.slice(0, 80)}...`,
      { parse_mode: 'Markdown', ...buttons }
    );
  }
};

module.exports = {
  showMainMenu,
  browseCategories,
  showProductsByCategory,
  showProductDetail,
  addToCart,
  viewCart,
  checkout,
  myOrders,
  handleSearch,
  getOrCreateUser
};
