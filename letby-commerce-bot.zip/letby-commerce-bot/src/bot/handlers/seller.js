const { Markup } = require('telegraf');
const User = require('../../models/User');
const Product = require('../../models/Product');
const Order = require('../../models/Order');

// Track seller registration sessions
const sellerSessions = {};
const productSessions = {};

// ── Become a Seller ───────────────────────────────────────────────────
const startSellerRegistration = async (ctx) => {
  const userId = String(ctx.from.id);
  const user = await User.findOne({ telegramId: userId });

  if (user?.isVerifiedSeller) {
    return showSellerDashboard(ctx);
  }

  sellerSessions[userId] = { step: 'storeName' };
  await ctx.reply(
    `🏪 *Become a LetBy Seller*\n\nSell to thousands of buyers on Telegram!\n✅ Free to list\n✅ Only ${process.env.COMMISSION_PERCENT}% commission on sales\n\nLet's set up your store.\n\n*What is your store name?*`,
    { parse_mode: 'Markdown' }
  );
};

// ── Handle Seller Registration Steps ─────────────────────────────────
const handleSellerRegistration = async (ctx) => {
  const userId = String(ctx.from.id);
  const session = sellerSessions[userId];
  if (!session) return;

  const text = ctx.message.text;

  if (session.step === 'storeName') {
    session.storeName = text;
    session.step = 'description';
    await ctx.reply('✏️ Describe your store (what do you sell?):');
  
  } else if (session.step === 'description') {
    session.description = text;
    session.step = 'phone';
    await ctx.reply('📞 Your phone number (for order notifications):');
  
  } else if (session.step === 'phone') {
    session.phone = text;
    
    // Save seller to DB
    await User.findOneAndUpdate(
      { telegramId: userId },
      {
        role: 'seller',
        storeName: session.storeName,
        storeDescription: session.description,
        phone: session.phone,
        isVerifiedSeller: true
      },
      { upsert: true, new: true }
    );

    delete sellerSessions[userId];

    await ctx.reply(
      `🎉 *Store Created!*\n\n🏪 ${session.storeName}\nYou're now a LetBy seller!\n\nStart listing your products:`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('➕ List Product', 'list_product')],
          [Markup.button.callback('📦 My Products', 'my_products')],
          [Markup.button.callback('📊 Orders', 'seller_orders')]
        ])
      }
    );
  }
};

// ── Seller Dashboard ──────────────────────────────────────────────────
const showSellerDashboard = async (ctx) => {
  const userId = String(ctx.from.id);
  const user = await User.findOne({ telegramId: userId });
  const productCount = await Product.countDocuments({ sellerTelegramId: userId, isActive: true });
  const orderCount = await Order.countDocuments({ sellerTelegramId: userId });
  const revenue = await Order.aggregate([
    { $match: { sellerTelegramId: userId, 'payment.status': 'success' } },
    { $group: { _id: null, total: { $sum: '$subtotal' } } }
  ]);

  const totalRevenue = revenue[0]?.total || 0;

  await ctx.reply(
    `🏪 *${user.storeName}*\n\n` +
    `📦 Products: ${productCount}\n` +
    `📋 Orders: ${orderCount}\n` +
    `💰 Revenue: ${totalRevenue} ETB\n`,
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('➕ List New Product', 'list_product')],
        [Markup.button.callback('📦 My Products', 'my_products')],
        [Markup.button.callback('📋 My Orders', 'seller_orders')]
      ])
    }
  );
};

// ── Start Product Listing ─────────────────────────────────────────────
const startProductListing = async (ctx) => {
  const userId = String(ctx.from.id);
  productSessions[userId] = { step: 'name' };
  await ctx.reply('📦 *New Product Listing*\n\nProduct name:', { parse_mode: 'Markdown' });
};

// ── Handle Product Listing Steps ─────────────────────────────────────
const handleProductListing = async (ctx) => {
  const userId = String(ctx.from.id);
  const session = productSessions[userId];
  if (!session) return false;

  const text = ctx.message?.text;
  const photo = ctx.message?.photo;

  if (session.step === 'name') {
    session.name = text;
    session.step = 'description';
    await ctx.reply('📝 Product description:');

  } else if (session.step === 'description') {
    session.description = text;
    session.step = 'price';
    await ctx.reply('💰 Price in ETB (numbers only):');

  } else if (session.step === 'price') {
    if (isNaN(text)) return ctx.reply('Enter a valid number for price.');
    session.price = parseFloat(text);
    session.step = 'category';
    await ctx.reply('📂 Choose category:', Markup.inlineKeyboard([
      [Markup.button.callback('📱 Electronics', 'pcat_Electronics'), Markup.button.callback('👗 Fashion', 'pcat_Fashion')],
      [Markup.button.callback('🍔 Food', 'pcat_Food'), Markup.button.callback('💄 Beauty', 'pcat_Beauty')],
      [Markup.button.callback('🏠 Home', 'pcat_Home'), Markup.button.callback('📚 Books', 'pcat_Books')],
      [Markup.button.callback('⚽ Sports', 'pcat_Sports'), Markup.button.callback('📦 Other', 'pcat_Other')]
    ]));

  } else if (session.step === 'stock') {
    if (isNaN(text)) return ctx.reply('Enter a valid number for stock.');
    session.stock = parseInt(text);
    session.step = 'location';
    await ctx.reply('📍 Your location / delivery area:');

  } else if (session.step === 'location') {
    session.location = text;
    session.step = 'image';
    await ctx.reply('📸 Send a product photo (or type "skip"):');

  } else if (session.step === 'image') {
    if (photo) {
      session.image = photo[photo.length - 1].file_id; // largest size
    }
    await saveProduct(ctx, userId, session);
  } else if (session.step === 'image' && text === 'skip') {
    await saveProduct(ctx, userId, session);
  }

  return true;
};

const setProductCategory = async (ctx, category) => {
  const userId = String(ctx.from.id);
  const session = productSessions[userId];
  if (!session) return;
  session.category = category;
  session.step = 'stock';
  await ctx.answerCbQuery();
  await ctx.reply(`Category: ${category}\n\n📦 How many in stock?`);
};

const saveProduct = async (ctx, userId, session) => {
  const user = await User.findOne({ telegramId: userId });
  
  const product = await Product.create({
    sellerId: user._id,
    sellerTelegramId: userId,
    name: session.name,
    description: session.description,
    price: session.price,
    category: session.category,
    stock: session.stock || 1,
    location: session.location,
    images: session.image ? [session.image] : []
  });

  delete productSessions[userId];

  await ctx.reply(
    `✅ *Product Listed!*\n\n*${product.name}*\n💰 ${product.price} ETB\n📂 ${product.category}\n\nBuyers can find it now!`,
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('➕ List Another', 'list_product')],
        [Markup.button.callback('📦 My Products', 'my_products')],
        [Markup.button.callback('🏠 Dashboard', 'seller_dashboard')]
      ])
    }
  );
};

// ── Seller Orders ─────────────────────────────────────────────────────
const sellerOrders = async (ctx) => {
  const userId = String(ctx.from.id);
  const orders = await Order.find({ sellerTelegramId: userId })
    .sort({ createdAt: -1 })
    .limit(10);

  if (!orders.length) return ctx.reply('No orders yet.');

  const statusEmoji = { pending: '⏳', paid: '💰', confirmed: '👍', shipped: '🚚', delivered: '✅', cancelled: '❌' };

  for (const order of orders) {
    const text = `${statusEmoji[order.status]} *Order ${order.orderId}*\n` +
      `Product: ${order.product.name}\n` +
      `Amount: ${order.total} ETB\n` +
      `Status: ${order.status}`;

    const buttons = order.status === 'paid' ? Markup.inlineKeyboard([
      [Markup.button.callback('✅ Confirm Order', `confirm_order_${order._id}`)],
      [Markup.button.callback('🚚 Mark Shipped', `ship_order_${order._id}`)]
    ]) : Markup.inlineKeyboard([
      [Markup.button.callback('🚚 Mark Shipped', `ship_order_${order._id}`)]
    ]);

    await ctx.reply(text, { parse_mode: 'Markdown', ...buttons });
  }
};

// ── Check if in seller session ────────────────────────────────────────
const isInSellerSession = (userId) => !!sellerSessions[userId];
const isInProductSession = (userId) => !!productSessions[userId];

module.exports = {
  startSellerRegistration,
  handleSellerRegistration,
  showSellerDashboard,
  startProductListing,
  handleProductListing,
  setProductCategory,
  sellerOrders,
  isInSellerSession,
  isInProductSession
};
