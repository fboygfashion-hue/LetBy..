const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  telegramId: { type: String, required: true, unique: true },
  username: { type: String },
  firstName: { type: String },
  lastName: { type: String },
  phone: { type: String },
  role: { type: String, enum: ['buyer', 'seller', 'both', 'admin'], default: 'buyer' },
  
  // Seller-specific
  storeName: { type: String },
  storeDescription: { type: String },
  isVerifiedSeller: { type: Boolean, default: false },
  totalSales: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  
  // Buyer-specific
  cart: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, default: 1 }
  }],
  totalOrders: { type: Number, default: 0 },
  
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', userSchema);
