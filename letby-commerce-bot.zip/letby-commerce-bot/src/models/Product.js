const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  sellerTelegramId: { type: String, required: true },
  
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  originalPrice: { type: Number }, // for discount display
  
  category: { 
    type: String, 
    enum: ['Electronics', 'Fashion', 'Food', 'Beauty', 'Home', 'Books', 'Sports', 'Other'],
    required: true 
  },
  
  images: [{ type: String }], // Telegram file_ids
  stock: { type: Number, default: 1 },
  
  location: { type: String }, // seller location / delivery area
  deliveryAvailable: { type: Boolean, default: false },
  deliveryFee: { type: Number, default: 0 },
  
  isActive: { type: Boolean, default: true },
  views: { type: Number, default: 0 },
  totalSold: { type: Number, default: 0 },
  
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Index for fast category + active queries
productSchema.index({ category: 1, isActive: 1 });
productSchema.index({ name: 'text', description: 'text' });

module.exports = mongoose.model('Product', productSchema);
