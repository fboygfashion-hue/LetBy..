const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const orderSchema = new mongoose.Schema({
  orderId: { type: String, default: () => `LB-${uuidv4().slice(0,8).toUpperCase()}`, unique: true },
  
  buyerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  buyerTelegramId: { type: String, required: true },
  
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  sellerTelegramId: { type: String, required: true },
  
  product: {
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    name: { type: String },
    price: { type: Number },
    quantity: { type: Number, default: 1 },
    image: { type: String }
  },
  
  subtotal: { type: Number, required: true },
  deliveryFee: { type: Number, default: 0 },
  commission: { type: Number }, // LetBy's cut
  total: { type: Number, required: true },
  
  status: { 
    type: String, 
    enum: ['pending', 'paid', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded'],
    default: 'pending'
  },
  
  payment: {
    method: { type: String, enum: ['chapa', 'telebirr', 'mpesa', 'cash'] },
    transactionId: { type: String },
    chapaRef: { type: String },
    paidAt: { type: Date },
    status: { type: String, enum: ['pending', 'success', 'failed'], default: 'pending' }
  },
  
  delivery: {
    address: { type: String },
    phone: { type: String },
    notes: { type: String }
  },
  
  timeline: [{
    status: String,
    message: String,
    timestamp: { type: Date, default: Date.now }
  }],
  
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', orderSchema);
