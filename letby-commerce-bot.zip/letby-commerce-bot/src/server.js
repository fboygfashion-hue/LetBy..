require('dotenv').config();
const express = require('express');
const connectDB = require('./config/database');
const createBot = require('./bot/index');
const paymentRoutes = require('./api/routes/payment');

const app = express();
app.use(express.json());

// ── Health check ──────────────────────────────────────────────────────
app.get('/', (req, res) => res.json({ status: 'LetBy Commerce Bot Running ✅' }));

// ── Routes ────────────────────────────────────────────────────────────
app.use('/payment', paymentRoutes);

// ── Start ─────────────────────────────────────────────────────────────
const start = async () => {
  await connectDB();

  const bot = createBot();

  if (process.env.NODE_ENV === 'production' && process.env.WEBHOOK_URL) {
    // Webhook mode for production (Railway)
    const webhookPath = `/bot${process.env.BOT_TOKEN}`;
    app.use(bot.webhookCallback(webhookPath));
    await bot.telegram.setWebhook(`${process.env.WEBHOOK_URL}${webhookPath}`);
    console.log('Bot running via webhook');
  } else {
    // Polling mode for local development
    await bot.launch();
    console.log('Bot running via polling (dev mode)');
  }

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`LetBy Commerce Server running on port ${PORT}`);
  });

  // Graceful shutdown
  process.once('SIGINT', () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
};

start().catch(console.error);
