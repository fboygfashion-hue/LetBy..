const express = require('express');
const router = express.Router();
const Order = require('../../models/Order');
const { verifyPayment } = require('../../services/payment');

// Chapa sends POST to this URL after payment
router.post('/callback', async (req, res) => {
  try {
    const { trx_ref, status } = req.body;

    if (!trx_ref) return res.status(400).json({ error: 'No transaction ref' });

    // Verify with Chapa
    const verification = await verifyPayment(trx_ref);

    if (verification.status === 'success') {
      const order = await Order.findOneAndUpdate(
        { 'payment.chapaRef': trx_ref },
        {
          status: 'paid',
          'payment.status': 'success',
          'payment.paidAt': new Date(),
          $push: { timeline: { status: 'paid', message: 'Payment verified via Chapa' } }
        },
        { new: true }
      );

      if (order) {
        // Bot notification handled in bot/index.js confirm_payment action
        console.log(`Order ${order.orderId} payment verified`);
      }
    }

    res.status(200).json({ received: true });
  } catch (err) {
    console.error('Payment callback error:', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

// Manual verify endpoint
router.get('/verify/:txRef', async (req, res) => {
  try {
    const result = await verifyPayment(req.params.txRef);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
