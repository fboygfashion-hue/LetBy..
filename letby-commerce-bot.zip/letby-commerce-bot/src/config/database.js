const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('MongoDB Connected — LetBy Commerce DB Ready');
  } catch (error) {
    console.error('DB Connection Failed:', error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
