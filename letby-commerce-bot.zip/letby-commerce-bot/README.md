# LetBy Commerce Bot 🛍
## Ethiopia's Telegram Marketplace

---

## What This Does
- Buyers browse, search, cart, checkout inside Telegram
- Sellers list products with photos, manage orders
- Payments via Chapa (Telebirr + MPSA + Bank Transfer)
- LetBy earns commission on every sale

---

## Setup in 30 Minutes

### Step 1 — Get Your Bot Token
1. Open Telegram → search @BotFather
2. Send `/newbot`
3. Choose name: **LetBy Commerce**
4. Choose username: `LetByCommerceBot`
5. Copy the token

### Step 2 — MongoDB Database (Free)
1. Go to https://cloud.mongodb.com
2. Create free account → Create free cluster
3. Database Access → Add user (save username/password)
4. Network Access → Allow all IPs (0.0.0.0/0)
5. Connect → Copy connection string
6. Replace `<password>` in the string with your password

### Step 3 — Chapa Payment (Telebirr + MPSA)
1. Go to https://chapa.co
2. Create merchant account
3. Dashboard → API Keys → Copy Secret Key

### Step 4 — Deploy on Railway (Free)
1. Go to https://railway.app
2. Sign up → New Project → Deploy from GitHub
3. Upload this code to a GitHub repo first
4. Add environment variables (see .env.example)
5. Set NODE_ENV=production
6. Copy your Railway app URL

### Step 5 — Configure .env
```
BOT_TOKEN=          ← from BotFather
MONGODB_URI=        ← from MongoDB Atlas  
CHAPA_SECRET_KEY=   ← from Chapa dashboard
WEBHOOK_URL=        ← your Railway app URL
COMMISSION_PERCENT= 5
PORT=               3000
NODE_ENV=           production
ADMIN_TELEGRAM_ID=  your Telegram ID (get from @userinfobot)
```

### Step 6 — Deploy
```bash
npm install
npm start
```

---

## Bot Features

### For Buyers:
- 🔍 Browse by 8 categories
- 🔎 Search products by keyword
- 🛒 Cart system
- 💳 Pay with Telebirr / MPSA / Bank
- 📦 Order tracking
- 📋 Order history

### For Sellers:
- 🏪 Free store setup
- ➕ List products with photos
- 📦 Stock management
- 📋 Order notifications
- 📊 Revenue dashboard

---

## Revenue Model
Every sale → LetBy earns 5% commission (configurable in .env)

---

## Support
Built for LetBy Commerce by JAT-1
