import rateLimit from 'express-rate-limit';
import { redis } from '../config/redis';

// Global limiter — 100 requests per minute per IP
export const globalLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'TOO_MANY_REQUESTS' },
});

// Auth routes — strict to prevent brute force
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, error: 'AUTH_RATE_LIMIT' },
});

// Listing creation — prevent spam listings
export const createListingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  message: { success: false, error: 'LISTING_RATE_LIMIT' },
});

// Search — generous but cached via Redis anyway
export const searchLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  message: { success: false, error: 'SEARCH_RATE_LIMIT' },
});
