import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';

export class AppError extends Error {
  constructor(
    public message: string,
    public statusCode: number,
    public code?: string
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const errorMiddleware = (
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
): void => {
  // Zod validation errors
  if (err instanceof ZodError) {
    res.status(400).json({
      success: false,
      error: 'VALIDATION_ERROR',
      issues: err.flatten().fieldErrors,
    });
    return;
  }

  // JWT errors
  if (err instanceof TokenExpiredError) {
    res.status(401).json({ success: false, error: 'TOKEN_EXPIRED' });
    return;
  }

  if (err instanceof JsonWebTokenError) {
    res.status(401).json({ success: false, error: 'INVALID_TOKEN' });
    return;
  }

  // App errors (business logic)
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      success: false,
      error: err.code ?? 'APP_ERROR',
      message: err.message,
    });
    return;
  }

  // Unknown errors — log but don't expose internals
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    error: 'INTERNAL_SERVER_ERROR',
    message: 'Something went wrong',
  });
};
