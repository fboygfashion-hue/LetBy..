import { v2 as cloudinary } from 'cloudinary';
import { env } from './env';

cloudinary.config({
  cloud_name: env.CLOUDINARY_CLOUD_NAME,
  api_key: env.CLOUDINARY_API_KEY,
  api_secret: env.CLOUDINARY_API_SECRET,
  secure: true,
});

export { cloudinary };

export const uploadImage = async (
  filePath: string,
  folder: 'listings' | 'avatars' | 'verification'
): Promise<{ url: string; publicId: string }> => {
  const result = await cloudinary.uploader.upload(filePath, {
    folder: `letby/${folder}`,
    transformation: [
      { quality: 'auto:good' },
      { fetch_format: 'auto' },
      // Resize large images — optimized for low-bandwidth mobile
      { width: 1200, height: 1200, crop: 'limit' },
    ],
  });

  return {
    url: result.secure_url,
    publicId: result.public_id,
  };
};

export const deleteImage = async (publicId: string): Promise<void> => {
  await cloudinary.uploader.destroy(publicId);
};
