import crypto from 'crypto';
import { env } from '../config/env';

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  language_code?: string;
}

export interface TelegramInitData {
  user: TelegramUser;
  auth_date: number;
  hash: string;
  query_id?: string;
  chat_instance?: string;
}

/**
 * Verifies Telegram WebApp initData using HMAC-SHA256.
 * See: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export const verifyTelegramInitData = (
  rawInitData: string
): TelegramInitData => {
  const params = new URLSearchParams(rawInitData);
  const hash = params.get('hash');

  if (!hash) throw new Error('Missing hash in initData');

  // Remove hash before building check string
  params.delete('hash');

  // Sort keys alphabetically and build data-check-string
  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');

  // HMAC key = HMAC-SHA256("WebAppData", bot_token)
  const secretKey = crypto
    .createHmac('sha256', 'WebAppData')
    .update(env.TELEGRAM_BOT_TOKEN)
    .digest();

  const expectedHash = crypto
    .createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex');

  if (expectedHash !== hash) {
    throw new Error('Invalid Telegram initData signature');
  }

  // Auth date must be within 24 hours (prevents replay attacks)
  const authDate = parseInt(params.get('auth_date') ?? '0', 10);
  const now = Math.floor(Date.now() / 1000);
  if (now - authDate > 86400) {
    throw new Error('Telegram initData has expired');
  }

  const userRaw = params.get('user');
  if (!userRaw) throw new Error('Missing user in initData');

  return {
    user: JSON.parse(decodeURIComponent(userRaw)) as TelegramUser,
    auth_date: authDate,
    hash,
    query_id: params.get('query_id') ?? undefined,
  };
};
