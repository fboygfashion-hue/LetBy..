/**
 * Trust score is computed dynamically, never stored.
 * This keeps it honest — sellers can't game a cached number.
 */

export interface TrustInput {
  avgRating: number;          // 0–5
  totalReviews: number;
  completedSales: number;
  scamReports: number;
  isVerified: boolean;
  responseTimeMinutes: number; // average
  repeatBuyers: number;
}

export interface TrustResult {
  score: number;              // 0–5 normalized
  label: 'LOW RISK' | 'MEDIUM RISK' | 'HIGH RISK' | 'UNVERIFIED';
  details: {
    ratingScore: number;
    activityScore: number;
    verificationBonus: number;
    penaltyScore: number;
  };
}

export const computeTrustScore = (input: TrustInput): TrustResult => {
  // Rating component (0–2.5 points)
  const ratingScore =
    input.totalReviews >= 3
      ? (input.avgRating / 5) * 2.5
      : input.totalReviews > 0
      ? (input.avgRating / 5) * 1.0
      : 0;

  // Activity component (0–1.5 points)
  const salesScore = Math.min(input.completedSales / 50, 1) * 0.75;
  const repeatScore = Math.min(input.repeatBuyers / 10, 1) * 0.5;
  const responseScore =
    input.responseTimeMinutes <= 5
      ? 0.25
      : input.responseTimeMinutes <= 30
      ? 0.15
      : 0;
  const activityScore = salesScore + repeatScore + responseScore;

  // Verification bonus (0–0.5 points)
  const verificationBonus = input.isVerified ? 0.5 : 0;

  // Penalty (scam reports are weighted heavily)
  const penaltyScore = Math.min(input.scamReports * 0.5, 2.5);

  const raw = ratingScore + activityScore + verificationBonus - penaltyScore;
  const score = Math.max(0, Math.min(5, parseFloat(raw.toFixed(1))));

  let label: TrustResult['label'];
  if (!input.isVerified) label = 'UNVERIFIED';
  else if (score >= 4.0) label = 'LOW RISK';
  else if (score >= 2.5) label = 'MEDIUM RISK';
  else label = 'HIGH RISK';

  return {
    score,
    label,
    details: { ratingScore, activityScore, verificationBonus, penaltyScore },
  };
};
