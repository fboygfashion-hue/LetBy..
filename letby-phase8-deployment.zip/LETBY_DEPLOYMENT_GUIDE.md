# LetBy — Production Deployment Guide

## Total time: ~45 minutes
## Cost: ~$0/month on free tiers

---

## Prerequisites

Install these if you don't have them:
```bash
npm install -g railway @railway/cli vercel
```

---

## STEP 1 — Database: Neon PostgreSQL (Free)

1. Go to https://neon.tech → Sign up
2. Create new project → Name: "letby"
3. Select region: closest to Ethiopia (eu-west-1 or us-east-1)
4. Copy the **pooled connection string**
   - Dashboard → Connection details → Pooled connection
   - Looks like: `postgresql://user:pass@ep-xxx.neon.tech/letby?sslmode=require&pgbouncer=true`
5. Save as `DATABASE_URL`

---

## STEP 2 — Redis: Upstash (Free)

1. Go to https://upstash.com → Sign up
2. Create database → Name: "letby" → Region: closest
3. Copy the **Redis URL** (starts with `rediss://`)
   - Console → Database → Details → Redis URL
4. Save as `REDIS_URL`

---

## STEP 3 — Image Hosting: Cloudinary (Free)

1. Go to https://cloudinary.com → Sign up
2. Dashboard → Account details
3. Copy: Cloud name, API Key, API Secret
4. Save as `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`

---

## STEP 4 — Telegram Bot: BotFather

1. Open Telegram → Search `@BotFather` → Start
2. Send `/newbot`
3. Name: `LetBy Marketplace`
4. Username: `LetByBot` (must end in "bot")
5. Copy the token → Save as `TELEGRAM_BOT_TOKEN`
6. Generate a webhook secret:
   ```bash
   openssl rand -hex 32
   ```
   Save as `TELEGRAM_BOT_SECRET`

7. Set bot description:
   ```
   /setdescription
   Trusted marketplace for Ethiopia. Verified sellers. Faster deals.
   ```

8. Set Mini App button (after deploying frontend):
   ```
   /setmenubutton
   → Select your bot
   → Set menu button URL: https://your-vercel-url.vercel.app
   → Button text: Open LetBy
   ```

---

## STEP 5 — Backend: Railway

### 5.1 Push code to GitHub

```bash
cd letby-backend
git init
git add .
git commit -m "feat: LetBy backend v1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/letby-backend.git
git push -u origin main
```

### 5.2 Deploy on Railway

```bash
railway login
railway init   # Select "Empty project", name it "letby-api"
railway up
```

Or via dashboard:
1. Go to https://railway.app → New Project
2. Deploy from GitHub → Select `letby-backend`
3. Railway auto-detects Dockerfile → Deploys

### 5.3 Set Environment Variables

In Railway dashboard → Your project → Variables → Raw Editor:

```
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://...     ← from Neon
REDIS_URL=rediss://...            ← from Upstash
JWT_SECRET=<openssl rand -hex 32>
JWT_EXPIRES_IN=7d
TELEGRAM_BOT_TOKEN=<from BotFather>
TELEGRAM_BOT_SECRET=<openssl rand -hex 32>
CLOUDINARY_CLOUD_NAME=<your name>
CLOUDINARY_API_KEY=<your key>
CLOUDINARY_API_SECRET=<your secret>
ADMIN_SECRET=<openssl rand -hex 32>
FRONTEND_URL=https://letby.vercel.app
ALLOWED_ORIGINS=https://letby.vercel.app
```

⚠️ Do NOT set `BACKEND_URL` yet — you need it in step 5.5

### 5.4 Run Database Migrations

```bash
railway run npx prisma migrate deploy
railway run npx tsx src/prisma/seed.ts
```

### 5.5 Set Backend URL

1. Railway dashboard → Your service → Settings → Networking → Generate Domain
2. Copy the URL (e.g., `https://letby-api.railway.app`)
3. Add to Railway env vars:
   ```
   BACKEND_URL=https://letby-api.railway.app
   ```
4. Redeploy:
   ```bash
   railway up
   ```

### 5.6 Verify deployment

```bash
curl https://letby-api.railway.app/health
# Should return: {"status":"ok","env":"production",...}
```

---

## STEP 6 — Frontend: Vercel

### 6.1 Push code to GitHub

```bash
cd letby-frontend
git init
git add .
git commit -m "feat: LetBy frontend v1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/letby-frontend.git
git push -u origin main
```

### 6.2 Deploy on Vercel

```bash
vercel login
vercel --prod
```

Or via dashboard:
1. Go to https://vercel.com → New Project
2. Import `letby-frontend` from GitHub
3. Framework: Vite (auto-detected)

### 6.3 Set Environment Variables

Vercel dashboard → Project → Settings → Environment Variables:

```
VITE_API_URL      = https://letby-api.railway.app/api
VITE_BOT_USERNAME = LetByBot
```

Set scope: **Production**

### 6.4 Redeploy with env vars

```bash
vercel --prod
```

### 6.5 Copy frontend URL

Example: `https://letby-abc123.vercel.app`

### 6.6 Update Backend CORS

In Railway env vars, update:
```
FRONTEND_URL=https://letby-abc123.vercel.app
ALLOWED_ORIGINS=https://letby-abc123.vercel.app
```

Redeploy backend.

---

## STEP 7 — Register Mini App with Telegram

1. Open Telegram → @BotFather
2. Send `/newapp`
3. Select your bot (`@LetByBot`)
4. App name: `LetBy`
5. App URL: `https://letby-abc123.vercel.app`
6. Description: `Trusted marketplace for Ethiopia`

Then set the menu button:
```
/setmenubutton
→ @LetByBot
→ URL: https://letby-abc123.vercel.app
→ Button text: Open LetBy
```

---

## STEP 8 — Create Admin Account

1. Open your bot in Telegram → /start
2. This creates your user in the database
3. Get your Telegram ID (bot should log it, or use @userinfobot)
4. Run in Railway console:
   ```bash
   railway run npx tsx -e "
   const { prisma } = require('./dist/config/prisma');
   prisma.user.update({
     where: { telegramId: 'YOUR_TELEGRAM_ID' },
     data: { role: 'ADMIN' }
   }).then(() => { console.log('Admin created'); process.exit(0); });
   "
   ```
5. Open the Mini App → Navigate to `/admin`

---

## STEP 9 — GitHub Actions CI/CD

### 9.1 Get Railway Token
```bash
railway tokens create letby-deploy
```

### 9.2 Get Railway Project ID
```bash
railway status
# Note the Project ID
```

### 9.3 Get Vercel Tokens

Vercel dashboard → Settings → Tokens → Create token

```bash
vercel link   # get org-id and project-id from .vercel/project.json
```

### 9.4 Add GitHub Secrets

GitHub repo → Settings → Secrets and variables → Actions:

**For backend repo:**
```
RAILWAY_TOKEN       = railway token from step 9.1
```

**For frontend repo:**
```
VERCEL_TOKEN        = your vercel token
VERCEL_ORG_ID       = from .vercel/project.json
VERCEL_PROJECT_ID   = from .vercel/project.json
VITE_API_URL        = https://letby-api.railway.app/api
VITE_BOT_USERNAME   = LetByBot
```

Now every `git push` to `main` auto-deploys. Zero manual steps.

---

## STEP 10 — Verify Everything Works

```bash
# 1. Health check
curl https://letby-api.railway.app/health

# 2. Auth endpoint
curl -X POST https://letby-api.railway.app/api/auth/telegram \
  -H "Content-Type: application/json" \
  -d '{"initData": "test"}'
# Should return 401 (invalid initData) — means server is up

# 3. Open bot in Telegram → type /start
# Should see welcome message

# 4. Type "phone" in bot
# Should see search results (or "no listings" if DB empty)

# 5. Open Mini App via menu button
# Should load LetBy marketplace
```

---

## Production Costs

| Service     | Tier         | Cost      |
|-------------|-------------|-----------|
| Railway     | Starter      | $5/month  |
| Neon DB     | Free         | $0        |
| Upstash     | Free (10k/day) | $0      |
| Cloudinary  | Free (25GB)  | $0        |
| Vercel      | Free         | $0        |
| **Total**   |              | **$5/month** |

At 1000+ active sellers → upgrade Railway to $20/month. That's it.

---

## Troubleshooting

**Bot not responding?**
```bash
# Check webhook status
curl https://api.telegram.org/bot<TOKEN>/getWebhookInfo
# Should show your Railway URL
```

**Database connection failing?**
```bash
railway run npx prisma db push
# Forces schema sync
```

**CORS errors in Mini App?**
- Check `ALLOWED_ORIGINS` matches your Vercel URL exactly
- No trailing slash

**Vercel build failing?**
```bash
# Test build locally first
npm run build
# Fix TypeScript errors, then push
```

---

## Post-Launch Checklist

- [ ] Bot responds to /start
- [ ] Mini App loads in Telegram
- [ ] Seller can submit verification
- [ ] Admin can approve/reject at /admin
- [ ] Listing appears in search
- [ ] Bot finds the listing
- [ ] ETB prices display correctly
- [ ] Images upload to Cloudinary

Ship it.
