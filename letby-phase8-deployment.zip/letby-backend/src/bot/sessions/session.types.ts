export interface BotSession {
  userId: string;
  chatId: number;
  state: 'home' | 'search_results' | 'listing_detail' | 'negotiation';
  searchQuery?: string;
  selectedListingId?: string;
  offerAmount?: number;
  originalPrice?: number;
  createdAt: number;
  updatedAt: number;
}

export interface SearchContext {
  query: string;
  results: any[];
  selectedIndex?: number;
}

export interface NegotiationContext {
  listingId: string;
  originalPrice: number;
  offerAmount?: number;
  stage: 'awaiting_offer' | 'confirm_offer' | 'sent';
}
