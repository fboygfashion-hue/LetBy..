import { cache } from '../../config/redis';
import type { BotSession } from './session.types';

const SESSION_TTL = 600; // 10 minutes

export const sessionManager = {
  async getSession(chatId: number): Promise<BotSession | null> {
    return cache.get(`telegram:${chatId}:session`);
  },

  async setState(chatId: number, state: BotSession['state']) {
    const session = (await cache.get<BotSession>(`telegram:${chatId}:session`)) || {
      chatId,
      userId: String(chatId),
      state: 'home',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    session.state = state;
    session.updatedAt = Date.now();
    await cache.set(`telegram:${chatId}:session`, session, SESSION_TTL);
  },

  async saveSession(chatId: number, session: Partial<BotSession>) {
    const current = (await cache.get<BotSession>(`telegram:${chatId}:session`)) || {
      chatId,
      userId: String(chatId),
      state: 'home',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    const updated = { ...current, ...session, updatedAt: Date.now() };
    await cache.set(`telegram:${chatId}:session`, updated, SESSION_TTL);
  },

  async clearSession(chatId: number) {
    await cache.del(`telegram:${chatId}:session`);
    await cache.del(`telegram:${chatId}:listing`);
    await cache.del(`telegram:${chatId}:negotiation`);
    await cache.del(`telegram:${chatId}:search_results`);
  },
};
