import { InlineKeyboardMarkup } from 'node-telegram-bot-api';

export const keyboards = {
  home: (): InlineKeyboardMarkup => ({
    inline_keyboard: [
      [
        { text: '🏠 Home', callback_data: 'home' },
        { text: '📖 Help', callback_data: 'help' },
      ],
    ],
  }),

  listingActions: (listingId: string): InlineKeyboardMarkup => ({
    inline_keyboard: [
      [
        { text: '📞 Contact', callback_data: 'contact_seller' },
        { text: '🎥 Video', callback_data: 'request_video' },
      ],
      [
        { text: '💬 Negotiate', callback_data: 'negotiate' },
        { text: '⭐ Reviews', callback_data: `review:${listingId}` },
      ],
      [
        { text: '📌 Reserve', callback_data: 'reserve' },
      ],
    ],
  }),

  negotiation: (): InlineKeyboardMarkup => ({
    inline_keyboard: [
      [
        { text: '✓ Send Offer', callback_data: 'send_offer' },
        { text: '✗ Cancel', callback_data: 'cancel_negotiation' },
      ],
    ],
  }),
};
