import TelegramBot from 'node-telegram-bot-api';
import express, { Request, Response } from 'express';
import { env } from '../config/env';
import { cache } from '../config/redis';
import { searchHandler } from './handlers/search.handler';
import { listingHandler } from './handlers/listing.handler';
import { negotiationHandler } from './handlers/negotiation.handler';
import { reviewHandler } from './handlers/review.handler';

const IS_PROD = env.NODE_ENV === 'production';

export const bot = IS_PROD
  ? new TelegramBot(env.TELEGRAM_BOT_TOKEN, { webHook: true })
  : new TelegramBot(env.TELEGRAM_BOT_TOKEN, { polling: true });

export const setupBotWebhook = (app: express.Application) => {
  if (!IS_PROD) {
    console.log('🤖 Bot polling (development)');
    return;
  }
  const path = `/webhook/${env.TELEGRAM_BOT_SECRET}`;
  bot.setWebHook(`${env.BACKEND_URL}${path}`, {
    allowed_updates: ['message', 'callback_query'],
    drop_pending_updates: true,
  }).then(() => console.log(`🤖 Webhook active`));

  app.post(path, (req: Request, res: Response) => {
    bot.processUpdate(req.body);
    res.sendStatus(200);
  });
};

bot.onText(/^\/start$/, async (msg) => {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId,
    `Welcome to LetBy AI Assistant.\n\nTrusted marketplace. Verified sellers. Faster deals.\n\nWhat are you looking for today?\n\nExamples:\n• iPhone 13\n• Gaming laptop\n• Sneakers\n• Furniture\n• Cars\n• Apartments\n\nType product name + budget if possible.`,
    { reply_markup: { inline_keyboard: [[{ text: '🏠 Home', callback_data: 'home' }, { text: '💬 Help', callback_data: 'help' }]] } }
  );
  await cache.set(`telegram:${chatId}:state`, 'home', 86400);
});

bot.onText(/^\/help$/, async (msg) => {
  await bot.sendMessage(msg.chat.id,
    `*LetBy Bot — Quick Guide*\n\n/start — Start shopping\n\n*How to buy:*\n1. Type what you want\n2. Select a listing\n3. Contact seller or negotiate`,
    { parse_mode: 'Markdown' }
  );
});

bot.on('message', async (msg) => {
  if (msg.text?.startsWith('/') || !msg.text) return;
  const chatId = msg.chat.id;
  try {
    const state = await cache.get<string>(`telegram:${chatId}:state`);
    if (state === 'negotiation') await negotiationHandler.handleOffer(bot, chatId, msg.text.trim());
    else await searchHandler.search(bot, chatId, msg.text.trim());
  } catch (err) {
    console.error('Bot error:', err);
    await bot.sendMessage(chatId, '❌ Something went wrong. Type /start to restart.');
  }
});

bot.on('callback_query', async (query) => {
  const chatId = query.message!.chat.id;
  const data   = query.data!;
  const msgId  = query.message!.message_id;
  try {
    if      (data.startsWith('listing:'))  await listingHandler.show(bot, chatId, data.split(':')[1], msgId);
    else if (data.startsWith('review:'))   await reviewHandler.show(bot, chatId, data.split(':')[1], msgId);
    else if (data === 'negotiate')         await negotiationHandler.start(bot, chatId, msgId);
    else if (data === 'contact_seller')    await listingHandler.contactSeller(bot, chatId, msgId);
    else if (data === 'request_video')     await listingHandler.requestVideo(bot, chatId, msgId);
    else if (data === 'reserve')           await listingHandler.reserve(bot, chatId, msgId);
    else if (data === 'home') {
      await bot.editMessageText('Welcome to LetBy AI Assistant.\n\nWhat are you looking for today?', { chat_id: chatId, message_id: msgId });
      await cache.set(`telegram:${chatId}:state`, 'home', 86400);
    }
    await bot.answerCallbackQuery(query.id);
  } catch (err) {
    console.error('Callback error:', err);
    await bot.answerCallbackQuery(query.id, { text: '❌ Error. Try again.' });
  }
});
