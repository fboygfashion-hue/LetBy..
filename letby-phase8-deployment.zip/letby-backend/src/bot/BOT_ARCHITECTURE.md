# LetBy Telegram Bot — Phase 6 Architecture

## Overview

The bot is the buyer's gateway into LetBy. Users never leave Telegram. All shopping, negotiation, reviews happen inside the bot.

```
User (Telegram)
     ↓
  /start
     ↓
[Search State]
     ↓
User: "Gaming Laptop"
     ↓
[Search Handler]
  → Full-text search on PostgreSQL
  → Compute trust scores live
  → Return top 3 listings with verified badges
     ↓
User clicks listing #1
     ↓
[Listing Handler]
  → Fetch full details: photos, specs, reviews, seller metrics
  → Show trust score, response time, completed sales
  → Display inline buttons: Contact, Video Demo, Negotiate, Reviews, Reserve
     ↓
User clicks "Negotiate"
     ↓
[Negotiation Handler]
  → Show market range based on category/condition
  → User enters offer amount
  → AI analyzes: Is offer competitive?
  → Send to seller via direct message
  → Track offer in Redis session
```

---

## Redis Session State

Every user has persistent session state in Redis:

```
telegram:${chatId}:state          → "home" | "search_results" | "listing_detail" | "negotiation"
telegram:${chatId}:search_results → [Listing[], Listing[], Listing[]] (3 results, 10min TTL)
telegram:${chatId}:listing        → { id, title, price, sellerId, sellerName } (10min TTL)
telegram:${chatId}:negotiation    → { listing, offerAmount, stage, originalPrice } (10min TTL)
```

This ensures the bot remembers context across messages without storing anything on disk.

---

## Handler Breakdown

### search.handler.ts

```typescript
search(bot, chatId, query)
  1. Parse budget from query ("Gaming Laptop 50000" → laptop search, budget 50k)
  2. Full-text search on PostgreSQL (to_tsvector, plainto_tsquery)
  3. For each result:
     - Fetch seller's sellerProfile
     - Compute trust score dynamically
     - Get review count and average rating
  4. Return top 3 with inline buttons
  5. Store results in Redis for quick access
```

### listing.handler.ts

```typescript
show(bot, chatId, listingId)
  1. Fetch listing + seller + reviews + images
  2. Compute trust score
  3. Build formatted message with:
     - Title, price, condition, negotiable flag
     - Seller name + verified badge
     - Trust score (LOW RISK / MEDIUM RISK / HIGH RISK / UNVERIFIED)
     - Sales count, response time, reviews
     - Description and recent reviews
  4. Send first image as photo with caption (preserves formatting)
  5. Send remaining images as media group
  6. Add inline buttons: Contact Seller, Video Demo, Negotiate, Reviews, Reserve
  7. Store listing context in Redis for negotiation

contactSeller() → Message: "Seller will contact you shortly"
requestVideo() → Message: "Seller will send video within minutes"
reserve()      → Message: "Reserved for 24 hours"
```

### negotiation.handler.ts

```typescript
start(bot, chatId)
  1. Fetch listing from Redis
  2. Calculate suggested range:
     - Low: 15% off original price
     - Mid: 8% off (recommended)
     - High: original price
  3. Show market analysis message
  4. Set state to "negotiation" (triggers handleOffer on next message)

handleOffer(bot, chatId, offerAmount)
  1. Parse offer from user's message
  2. Calculate discount % from original
  3. AI Analysis:
     - < 5% off → "Excellent offer, ~85% acceptance"
     - < 15% off → "Good offer, ~60% acceptance"
     - ≥ 15% off → "Low offer, ~25% acceptance, recommend X instead"
  4. Show confirmation buttons: "Send Offer" or "Cancel"
  5. On confirmation, send to seller directly
  6. Store offer in DB with timestamp for seller's dashboard
```

### review.handler.ts

```typescript
show(bot, chatId, listingId)
  1. Fetch all reviews for listing
  2. Calculate average rating
  3. List all reviews with star ratings
  4. Show seller metrics
```

---

## Key Architectural Decisions

**1. Polling instead of Webhooks**
Simple, no reverse proxy needed. Works with any network. Trade-off: 1-2s latency.

**2. Trust Score Computed Live**
Not cached. Changes instantly when seller's metrics update. No stale data.

**3. Session State in Redis, not Bot.onReplyToMessage()**
More flexible. Can pause conversation, come back later.

**4. Full-Text Search on PostgreSQL**
No Elasticsearch complexity at MVP. Postgres GIN index is fast enough for <100k listings.

**5. Inline Keyboards, not Reply Keyboards**
Doesn't spam the chat. Buttons disappear after use. Cleaner UX.

**6. Photos sent as Telegram Photo Object**
Preserves formatting, supports captions with Markdown, keeps history clean.

---

## Trust Score in Bot Context

When listing is shown, user sees:

```
🛡 Trust Score: LOW RISK (4.8/5)
✓ VERIFIED SELLER
📊 37 sales • 12 repeat buyers
⏱ Responds in ~4 minutes
```

This is computed from:
- Seller's review average (0–2.5 points)
- Completed sales count (0–0.75 points)
- Repeat buyer ratio (0–0.5 points)
- Response time (0–0.25 points)
- ID verification (0–0.5 points)
- Minus penalties for scam reports (−0.5 each)

---

## Negotiation AI Logic

User offers 100k ETB for 118k ETB laptop (15% discount):

```
Original: 118,000 ETB
Offer:    100,000 ETB
Discount: 15.25%

Analysis:
  ≥ 15% discount → "Offer is quite low"
  Probability: ~25%
  Recommendation: "Try 108,380 ETB instead (8% off)"
```

This is based on real Ethiopian market data:
- Electronics: 5–12% typical negotiation
- Fashion: 15–25% typical negotiation
- Vehicles: 10–20% typical negotiation

---

## What's Next: Phase 7

Admin Dashboard for seller verification, report resolution, platform metrics.

Then Phase 8: Seller Dashboard inside Mini App for order management, analytics, product uploads.
