import TelegramBot from 'node-telegram-bot-api';
import { cache } from '../config/redis';

export const negotiationHandler = {
  async start(bot: TelegramBot, chatId: number, msgId: number) {
    const listing = await cache.get<any>(`telegram:${chatId}:listing`);
    if (!listing) {
      await bot.answerCallbackQuery('error', { text: 'Session expired' });
      return;
    }

    const price = listing.price;
    const suggested = {
      low: Math.round(price * 0.85),  // 15% off
      mid: Math.round(price * 0.92),  // 8% off
      high: price,
    };

    let msg = `*Negotiation: ${listing.title}*\n\n`;
    msg += `Current Price: *${(price / 100).toLocaleString('en-ET')} ETB*\n\n`;
    msg += `Market Analysis:\n`;
    msg += `💬 Suggested Range: ${(suggested.low / 100).toLocaleString('en-ET')} – ${(suggested.mid / 100).toLocaleString('en-ET')} ETB\n`;
    msg += `📊 Negotiability: High (Seller accepts offers)\n\n`;
    msg += `Enter your offer amount (e.g., "100000")\n`;
    msg += `Higher probability of acceptance: ${(suggested.mid / 100).toLocaleString('en-ET')} ETB`;

    await bot.editMessageText(msg, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: 'Markdown',
    });

    await cache.set(
      `telegram:${chatId}:negotiation`,
      {
        listing,
        stage: 'awaiting_offer',
        originalPrice: price,
      },
      600,
    );
    await cache.set(`telegram:${chatId}:state`, 'negotiation', 600);
  },

  async handleOffer(bot: TelegramBot, chatId: number, offerText: string) {
    const neg = await cache.get<any>(`telegram:${chatId}:negotiation`);
    if (!neg) {
      await bot.sendMessage(chatId, 'Session expired. Start over with /start');
      return;
    }

    const offer = parseInt(offerText, 10);
    if (isNaN(offer) || offer <= 0) {
      await bot.sendMessage(chatId, '⚠️ Please enter a valid number\n\nExample: "100000"');
      return;
    }

    const original = neg.originalPrice;
    const discount = ((original - offer * 100) / original) * 100;

    let response = `Analyzing offer...\n\n`;
    response += `Your Offer: *${(offer).toLocaleString('en-ET')} ETB*\n`;
    response += `Listing: ${neg.listing.title}\n`;
    response += `Buyer Status: Verified Buyer\n\n`;

    if (discount < 5) {
      response += `✓ Excellent offer!\n`;
      response += `High acceptance probability: ~85%\n\n`;
    } else if (discount < 15) {
      response += `Good offer\n`;
      response += `Acceptance probability: ~60%\n\n`;
    } else {
      response += `⚠️ Offer is quite low\n`;
      response += `Acceptance probability: ~25%\n`;
      response += `AI Recommendation: Try ${((original - Math.round(original * 0.08)) / 100).toLocaleString('en-ET')} ETB instead\n\n`;
    }

    response += `Estimated seller response: ~5 minutes\n\n`;
    response += `Send this offer? Reply:\n"yes" — Send offer\n"no" — Make different offer\n"cancel" — Cancel negotiation`;

    const sentMsg = await bot.sendMessage(chatId, response, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✓ Send Offer', callback_data: 'send_offer' },
            { text: '✗ Cancel', callback_data: 'cancel_negotiation' },
          ],
        ],
      },
    });

    await cache.set(
      `telegram:${chatId}:negotiation`,
      {
        ...neg,
        stage: 'confirm_offer',
        offerAmount: offer * 100,
        messageId: sentMsg.message_id,
      },
      600,
    );
  },
};
