import TelegramBot from 'node-telegram-bot-api';
import { prisma } from '../config/prisma';
import { cache } from '../config/redis';
import { computeTrustScore } from '../utils/trust.score';

export const listingHandler = {
  async show(bot: TelegramBot, chatId: number, listingId: string, msgId?: number) {
    try {
      const listing = await prisma.listing.findUnique({
        where: { id: listingId },
        include: {
          images: { orderBy: { sortOrder: 'asc' } },
          category: true,
          seller: {
            include: {
              sellerProfile: true,
              _count: { select: { reviewsReceived: true } },
            },
          },
          reviews: {
            take: 3,
            orderBy: { createdAt: 'desc' },
            include: { author: true },
          },
        },
      });

      if (!listing) {
        await bot.sendMessage(chatId, '❌ Listing not found');
        return;
      }

      const seller = listing.seller;
      const profile = seller.sellerProfile;
      const trustScore = computeTrustScore({
        avgRating: listing.reviews.length > 0
          ? listing.reviews.reduce((sum, r) => sum + r.rating, 0) / listing.reviews.length
          : 0,
        totalReviews: listing.reviews.length,
        completedSales: profile?.totalSales ?? 0,
        scamReports: profile?.scamReports ?? 0,
        isVerified: profile?.isVerified ?? false,
        responseTimeMinutes: profile?.avgResponseMin ?? 999,
        repeatBuyers: 0,
      });

      // Format listing details
      let details = `*${listing.title}*\n\n`;
      details += `💰 *${(listing.price / 100).toLocaleString('en-ET')} ETB*\n`;
      details += `📦 Condition: *${listing.condition.replace('_', ' ')}*\n`;
      details += `📍 ${listing.location}\n`;
      details += `${listing.isNegotiable ? '💬 *Negotiable*\n' : ''}`;

      // Seller info
      details += `\n*Seller: ${seller.firstName}*\n`;
      details += `🛡 Trust Score: *${trustScore.label}* (${trustScore.score}/5)\n`;
      details += `${profile?.isVerified ? '✓ *VERIFIED SELLER*\n' : ''}`;
      details += `📊 ${profile?.totalSales ?? 0} sales • ${listing.reviews.length} reviews\n`;
      details += `⏱ Responds in ~${profile?.avgResponseMin ?? '?'} minutes\n`;

      // Description
      if (listing.description) {
        details += `\n*About:*\n${listing.description}\n`;
      }

      // Recent reviews
      if (listing.reviews.length > 0) {
        details += `\n*Recent Reviews:*\n`;
        listing.reviews.forEach((r) => {
          details += `${'⭐'.repeat(r.rating)} ${r.author.firstName}\n`;
          if (r.comment) details += `"${r.comment}"\n`;
        });
      }

      // Send photos if exist
      if (listing.images.length > 0) {
        // Send first image with details
        await bot.sendPhoto(chatId, listing.images[0].url, {
          caption: details,
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📞 Contact Seller', callback_data: 'contact_seller' },
                { text: '🎥 Video Demo', callback_data: 'request_video' },
              ],
              [
                { text: '💬 Negotiate', callback_data: 'negotiate' },
                { text: '⭐ Reviews', callback_data: `review:${listingId}` },
              ],
              [
                { text: '📌 Reserve', callback_data: 'reserve' },
              ],
            ],
          },
        });

        // Send remaining images as document gallery
        if (listing.images.length > 1) {
          const mediaGroup = listing.images.slice(1, 5).map((img) => ({
            type: 'photo' as const,
            media: img.url,
          }));
          await bot.sendMediaGroup(chatId, mediaGroup);
        }
      } else {
        await bot.sendMessage(chatId, details, {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📞 Contact Seller', callback_data: 'contact_seller' },
                { text: '🎥 Video Demo', callback_data: 'request_video' },
              ],
              [
                { text: '💬 Negotiate', callback_data: 'negotiate' },
                { text: '⭐ Reviews', callback_data: `review:${listingId}` },
              ],
              [
                { text: '📌 Reserve', callback_data: 'reserve' },
              ],
            ],
          },
        });
      }

      // Store context for negotiations
      await cache.set(
        `telegram:${chatId}:listing`,
        {
          id: listingId,
          title: listing.title,
          price: listing.price,
          sellerId: seller.id,
          sellerName: seller.firstName,
        },
        600,
      );

      await cache.set(`telegram:${chatId}:state`, 'listing_detail', 600);
    } catch (err) {
      console.error('Listing handler error:', err);
      await bot.sendMessage(chatId, '❌ Failed to load listing details');
    }
  },

  async contactSeller(bot: TelegramBot, chatId: number, msgId: number) {
    const listing = await cache.get<any>(`telegram:${chatId}:listing`);
    if (!listing) {
      await bot.answerCallbackQuery('session', { text: 'Session expired. Start over.' });
      return;
    }

    await bot.editMessageText(
      `Connecting you to the seller...\n\nSeller: ${listing.sellerName}\nProduct: ${listing.title}\n\nThe seller will contact you shortly on Telegram.`,
      { chat_id: chatId, message_id: msgId },
    );
  },

  async requestVideo(bot: TelegramBot, chatId: number, msgId: number) {
    const listing = await cache.get<any>(`telegram:${chatId}:listing`);
    if (!listing) return;

    await bot.editMessageText(
      `Requested video demo for:\n${listing.title}\n\nSeller will send you a video within a few minutes.`,
      { chat_id: chatId, message_id: msgId },
    );
  },

  async reserve(bot: TelegramBot, chatId: number, msgId: number) {
    const listing = await cache.get<any>(`telegram:${chatId}:listing`);
    if (!listing) return;

    await bot.editMessageText(
      `✓ ${listing.title} has been reserved for 24 hours.\n\nThe seller will contact you to finalize the deal.`,
      { chat_id: chatId, message_id: msgId },
    );
  },
};
