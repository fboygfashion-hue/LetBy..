import TelegramBot from 'node-telegram-bot-api';
import { prisma } from '../config/prisma';

export const reviewHandler = {
  async show(bot: TelegramBot, chatId: number, listingId: string, msgId?: number) {
    try {
      const listing = await prisma.listing.findUnique({
        where: { id: listingId },
        include: {
          seller: true,
          reviews: {
            orderBy: { createdAt: 'desc' },
            include: { author: true },
          },
        },
      });

      if (!listing) {
        await bot.sendMessage(chatId, '❌ Listing not found');
        return;
      }

      const reviews = listing.reviews;
      const avgRating = reviews.length > 0
        ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
        : '—';

      let msg = `*Reviews for ${listing.title}*\n\n`;
      msg += `⭐ Average: ${avgRating}/5 (${reviews.length} reviews)\n`;
      msg += `Seller: ${listing.seller.firstName}\n\n`;

      if (reviews.length === 0) {
        msg += `No reviews yet. Be the first to review!`;
      } else {
        reviews.forEach((r) => {
          msg += `${'⭐'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}\n`;
          msg += `${r.author.firstName}\n`;
          if (r.comment) msg += `"${r.comment}"\n`;
          msg += `\n`;
        });
      }

      if (msgId) {
        await bot.editMessageText(msg, {
          chat_id: chatId,
          message_id: msgId,
          parse_mode: 'Markdown',
        });
      } else {
        await bot.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
      }
    } catch (err) {
      console.error('Review handler error:', err);
      await bot.sendMessage(chatId, '❌ Failed to load reviews');
    }
  },
};
