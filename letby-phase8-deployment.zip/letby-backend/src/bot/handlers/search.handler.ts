import TelegramBot from 'node-telegram-bot-api';
import { prisma } from '../config/prisma';
import { cache } from '../config/redis';
import { computeTrustScore } from '../utils/trust.score';
import { formatETB } from '@/lib/api';

interface SearchResult {
  id: string;
  title: string;
  price: number;
  seller: { id: string; firstName: string; sellerProfile: { isVerified: boolean; scamReports: number; totalSales: number; avgResponseMin: number } | null };
  images: { url: string }[];
  reviewCount?: number;
  avgRating?: number;
}

export const searchHandler = {
  async search(bot: TelegramBot, chatId: number, query: string) {
    // Parse budget if included (e.g., "Gaming Laptop 50000")
    const parts = query.split(/\s+/);
    const lastPart = parts[parts.length - 1];
    const budget = !isNaN(parseFloat(lastPart)) ? Math.round(parseFloat(lastPart) * 100) : null;
    const searchQ = budget ? parts.slice(0, -1).join(' ') : query;

    await bot.sendMessage(chatId, '🔍 Searching verified sellers...');

    try {
      // Raw SQL search with trust score calculation
      const listings = await prisma.$queryRaw<SearchResult[]>`
        SELECT
          l.id,
          l.title,
          l.price,
          l."viewCount",
          json_build_object(
            'id', u.id,
            'firstName', u."firstName",
            'sellerProfile', json_build_object(
              'isVerified', sp."isVerified",
              'scamReports', sp."scamReports",
              'totalSales', sp."totalSales",
              'avgResponseMin', sp."avgResponseMin"
            )
          ) AS seller,
          COALESCE(
            json_agg(json_build_object('url', li.url)) 
            FILTER (WHERE li.id IS NOT NULL),
            '[]'::json
          ) AS images,
          COUNT(DISTINCT r.id) AS "reviewCount",
          ROUND(AVG(r.rating)::numeric, 1) AS "avgRating"
        FROM "Listing" l
        JOIN "User" u ON l."sellerId" = u.id
        LEFT JOIN "SellerProfile" sp ON u.id = sp."userId"
        LEFT JOIN "ListingImage" li ON l.id = li."listingId"
        LEFT JOIN "Review" r ON l.id = r."listingId"
        WHERE 
          l.status = 'ACTIVE'
          AND to_tsvector('english', l.title || ' ' || COALESCE(l.description, ''))
              @@ plainto_tsquery('english', ${searchQ})
          ${budget ? `AND l.price <= ${budget + 50000}` : ''}
        GROUP BY l.id, u.id, sp.id
        ORDER BY sp."isVerified" DESC, COUNT(r.id) DESC
        LIMIT 20
      `;

      if (!listings || listings.length === 0) {
        await bot.sendMessage(chatId, `No listings found for "${query}".\n\nTry:\n• Different keywords\n• Lower price budget\n• Browse by category`, {
          reply_markup: {
            inline_keyboard: [[
              { text: '🏠 Home', callback_data: 'home' },
            ]],
          },
        });
        await cache.set(`telegram:${chatId}:state`, 'home', 86400);
        return;
      }

      // Build results message
      let msg = `Found ${listings.length} matching listings:\n\n`;

      listings.slice(0, 3).forEach((item, i) => {
        const seller = item.seller;
        const isVerified = seller.sellerProfile?.isVerified ?? false;
        const trustScore = computeTrustScore({
          avgRating: item.avgRating ? parseFloat(item.avgRating.toString()) : 0,
          totalReviews: item.reviewCount ?? 0,
          completedSales: seller.sellerProfile?.totalSales ?? 0,
          scamReports: seller.sellerProfile?.scamReports ?? 0,
          isVerified,
          responseTimeMinutes: seller.sellerProfile?.avgResponseMin ?? 999,
          repeatBuyers: 0,
        });

        msg += `*${i + 1}. ${item.title}*\n`;
        msg += `🏷 ${(item.price / 100).toLocaleString('en-ET')} ETB\n`;
        msg += `🛡 Trust: ${trustScore.label} (${trustScore.score}/5)\n`;
        msg += `${isVerified ? '✓ ' : ''}${seller.firstName} • ${item.reviewCount ?? 0} reviews\n\n`;
      });

      msg += 'Reply with number to view details:\nExample: "1"';

      const sentMsg = await bot.sendMessage(chatId, msg, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: listings.slice(0, 3).map((item, i) => [
            { text: `${i + 1}. ${item.title.slice(0, 25)}...`, callback_data: `listing:${item.id}` },
          ]),
        },
      });

      // Store listings in Redis for quick access
      await cache.set(`telegram:${chatId}:search_results`, listings.slice(0, 3), 600);
      await cache.set(`telegram:${chatId}:state`, 'search_results', 600);
    } catch (err) {
      console.error('Search error:', err);
      await bot.sendMessage(chatId, '❌ Search failed. Try again.');
    }
  },
};
