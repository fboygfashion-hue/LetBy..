import { prisma } from '../../config/prisma';
import { cache } from '../../config/redis';
import { AppError } from '../../middleware/error.middleware';
import type { ReviewVerificationInput, ResolveReportInput, RemoveListingInput } from './admin.validator';

export const adminService = {

  async getMetrics() {
    const cacheKey = 'admin:metrics';
    const cached = await cache.get<object>(cacheKey);
    if (cached) return cached;

    const [totalUsers, totalSellers, verifiedSellers, totalListings, activeListings,
           totalReviews, pendingVerifications, openReports] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: 'SELLER' } }),
      prisma.sellerProfile.count({ where: { isVerified: true } }),
      prisma.listing.count(),
      prisma.listing.count({ where: { status: 'ACTIVE' } }),
      prisma.review.count(),
      prisma.verificationRequest.count({ where: { status: 'PENDING' } }),
      prisma.report.count({ where: { status: 'OPEN' } }),
    ]);

    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [newUsersThisWeek, newListingsThisWeek] = await Promise.all([
      prisma.user.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
      prisma.listing.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    ]);

    const metrics = {
      totalUsers, totalSellers, verifiedSellers,
      verificationRate: totalSellers > 0 ? Math.round((verifiedSellers / totalSellers) * 100) : 0,
      totalListings, activeListings, totalReviews,
      pendingVerifications, openReports,
      newUsersThisWeek, newListingsThisWeek,
    };

    await cache.set(cacheKey, metrics, 300);
    return metrics;
  },

  async getVerificationQueue(page: number, limit: number, status?: string) {
    const skip = (page - 1) * limit;
    const where = status ? { status: status as any } : {};
    const [items, total] = await Promise.all([
      prisma.verificationRequest.findMany({
        where, skip, take: limit, orderBy: { submittedAt: 'asc' },
        include: {
          user: {
            select: {
              id: true, firstName: true, lastName: true, telegramUsername: true, photoUrl: true,
              sellerProfile: { select: { shopName: true } },
            },
          },
        },
      }),
      prisma.verificationRequest.count({ where }),
    ]);
    return { data: items, total, page, limit, hasMore: skip + items.length < total };
  },

  async reviewVerification(verificationId: string, adminId: string, input: ReviewVerificationInput) {
    const verification = await prisma.verificationRequest.findUnique({
      where: { id: verificationId }, include: { user: true },
    });
    if (!verification) throw new AppError('Not found', 404, 'NOT_FOUND');
    if (verification.status !== 'PENDING') throw new AppError('Already reviewed', 409, 'ALREADY_REVIEWED');

    await prisma.$transaction(async (tx) => {
      await tx.verificationRequest.update({
        where: { id: verificationId },
        data: { status: input.status, reviewedBy: adminId, reviewNote: input.reviewNote ?? null, reviewedAt: new Date() },
      });
      if (input.status === 'APPROVED') {
        await tx.sellerProfile.update({ where: { userId: verification.userId }, data: { isVerified: true, verifiedAt: new Date() } });
      }
      await tx.adminLog.create({ data: { adminId, action: `VERIFICATION_${input.status}`, targetType: 'USER', targetId: verification.userId, note: input.reviewNote } });
      await tx.notification.create({
        data: {
          userId: verification.userId,
          type: input.status === 'APPROVED' ? 'VERIFICATION_APPROVED' : 'VERIFICATION_REJECTED',
          title: input.status === 'APPROVED' ? 'Verification Approved' : 'Verification Rejected',
          body: input.status === 'APPROVED'
            ? 'Your account is verified. Buyers will see your trust badge.'
            : `Rejected: ${input.reviewNote ?? 'See guidelines.'}`,
        },
      });
    });
    await cache.del('admin:metrics');
    return { status: input.status };
  },

  async getReports(page: number, limit: number, status?: string) {
    const skip = (page - 1) * limit;
    const where = status ? { status: status as any } : {};
    const [items, total] = await Promise.all([
      prisma.report.findMany({
        where, skip, take: limit, orderBy: { createdAt: 'desc' },
        include: {
          reporter: { select: { id: true, firstName: true, telegramUsername: true } },
          listing: { select: { id: true, title: true, price: true } },
          reportedUser: {
            select: { id: true, firstName: true, sellerProfile: { select: { shopName: true, isVerified: true, scamReports: true } } },
          },
        },
      }),
      prisma.report.count({ where }),
    ]);
    return { data: items, total, page, limit, hasMore: skip + items.length < total };
  },

  async resolveReport(reportId: string, adminId: string, input: ResolveReportInput) {
    const report = await prisma.report.findUnique({ where: { id: reportId } });
    if (!report) throw new AppError('Not found', 404, 'NOT_FOUND');
    if (report.status !== 'OPEN') throw new AppError('Already resolved', 409, 'ALREADY_RESOLVED');

    await prisma.$transaction(async (tx) => {
      await tx.report.update({
        where: { id: reportId },
        data: { status: input.status, resolvedBy: adminId, resolvedNote: input.resolvedNote ?? null, resolvedAt: new Date() },
      });
      if (input.banSeller && report.reportedUserId) {
        await tx.user.update({ where: { id: report.reportedUserId }, data: { isActive: false } });
        await tx.listing.updateMany({ where: { sellerId: report.reportedUserId }, data: { status: 'REMOVED' } });
        await tx.sellerProfile.update({ where: { userId: report.reportedUserId }, data: { scamReports: { increment: 1 } } });
      }
      await tx.adminLog.create({ data: { adminId, action: `REPORT_${input.status}`, targetType: 'REPORT', targetId: reportId, note: input.resolvedNote } });
    });
    await cache.del('admin:metrics');
    return { status: input.status };
  },

  async getAllListings(page: number, limit: number, status?: string) {
    const skip = (page - 1) * limit;
    const where = status ? { status: status as any } : {};
    const [items, total] = await Promise.all([
      prisma.listing.findMany({
        where, skip, take: limit, orderBy: { createdAt: 'desc' },
        include: {
          category: true,
          images: { take: 1, orderBy: { sortOrder: 'asc' } },
          seller: { select: { id: true, firstName: true, telegramUsername: true, sellerProfile: { select: { isVerified: true, shopName: true } } } },
          _count: { select: { reviews: true, reports: true } },
        },
      }),
      prisma.listing.count({ where }),
    ]);
    return { data: items, total, page, limit, hasMore: skip + items.length < total };
  },

  async removeListing(listingId: string, adminId: string, input: RemoveListingInput) {
    const listing = await prisma.listing.findUnique({ where: { id: listingId } });
    if (!listing) throw new AppError('Not found', 404, 'NOT_FOUND');
    await prisma.$transaction(async (tx) => {
      await tx.listing.update({ where: { id: listingId }, data: { status: 'REMOVED' } });
      await tx.notification.create({
        data: { userId: listing.sellerId, type: 'LISTING_REMOVED', title: 'Listing Removed', body: `Reason: ${input.reason}`, metadata: { listingId, reason: input.reason } },
      });
      await tx.adminLog.create({ data: { adminId, action: 'LISTING_REMOVED', targetType: 'LISTING', targetId: listingId, note: input.reason } });
    });
    await cache.del('admin:metrics');
    return { removed: true };
  },

  async getAllUsers(page: number, limit: number) {
    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      prisma.user.findMany({
        skip, take: limit, orderBy: { createdAt: 'desc' },
        select: {
          id: true, firstName: true, lastName: true, telegramUsername: true, role: true, isActive: true, createdAt: true,
          sellerProfile: { select: { isVerified: true, totalSales: true, scamReports: true } },
          _count: { select: { listings: true, reviewsReceived: true } },
        },
      }),
      prisma.user.count(),
    ]);
    return { data: items, total, page, limit, hasMore: skip + items.length < total };
  },

  async getAdminLogs(page: number, limit: number) {
    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      prisma.adminLog.findMany({ skip, take: limit, orderBy: { createdAt: 'desc' } }),
      prisma.adminLog.count(),
    ]);
    return { data: items, total, page, limit };
  },
};
