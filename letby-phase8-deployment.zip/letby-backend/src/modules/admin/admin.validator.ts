import { z } from 'zod';

export const reviewVerificationSchema = z.object({
  status: z.enum(['APPROVED', 'REJECTED']),
  reviewNote: z.string().max(500).optional(),
});

export const resolveReportSchema = z.object({
  status: z.enum(['RESOLVED', 'DISMISSED']),
  resolvedNote: z.string().max(500).optional(),
  banSeller: z.boolean().default(false),
});

export const removeListingSchema = z.object({
  reason: z.string().min(5).max(300),
});

export const adminQuerySchema = z.object({
  page:   z.string().default('1').transform(Number),
  limit:  z.string().default('20').transform(Number),
  status: z.string().optional(),
});

export type ReviewVerificationInput = z.infer<typeof reviewVerificationSchema>;
export type ResolveReportInput      = z.infer<typeof resolveReportSchema>;
export type RemoveListingInput      = z.infer<typeof removeListingSchema>;
