import { Request, Response, NextFunction } from 'express';
import { adminService } from './admin.service';

export const adminController = {
  async getMetrics(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await adminService.getMetrics();
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async getVerificationQueue(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 20, status } = req.query as any;
      const data = await adminService.getVerificationQueue(Number(page), Number(limit), status);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async reviewVerification(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await adminService.reviewVerification(req.params.id, req.user!.userId, req.body);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async getReports(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 20, status } = req.query as any;
      const data = await adminService.getReports(Number(page), Number(limit), status);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async resolveReport(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await adminService.resolveReport(req.params.id, req.user!.userId, req.body);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async getAllListings(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 20, status } = req.query as any;
      const data = await adminService.getAllListings(Number(page), Number(limit), status);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async removeListing(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await adminService.removeListing(req.params.id, req.user!.userId, req.body);
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async getAllUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 20 } = req.query as any;
      const data = await adminService.getAllUsers(Number(page), Number(limit));
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },

  async getAdminLogs(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 50 } = req.query as any;
      const data = await adminService.getAdminLogs(Number(page), Number(limit));
      res.json({ success: true, data });
    } catch (err) { next(err); }
  },
};
