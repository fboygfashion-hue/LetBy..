import { Router } from 'express';
import { adminController } from './admin.controller';
import { authenticate, requireRole } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { reviewVerificationSchema, resolveReportSchema, removeListingSchema } from './admin.validator';

const router = Router();

// All admin routes require authentication + ADMIN role
router.use(authenticate, requireRole('ADMIN'));

// Dashboard
router.get('/metrics',                    adminController.getMetrics);
router.get('/logs',                       adminController.getAdminLogs);

// Verification queue
router.get('/verifications',              adminController.getVerificationQueue);
router.put('/verifications/:id/review',   validate(reviewVerificationSchema), adminController.reviewVerification);

// Reports
router.get('/reports',                    adminController.getReports);
router.put('/reports/:id/resolve',        validate(resolveReportSchema), adminController.resolveReport);

// Listings
router.get('/listings',                   adminController.getAllListings);
router.delete('/listings/:id',            validate(removeListingSchema), adminController.removeListing);

// Users
router.get('/users',                      adminController.getAllUsers);

export default router;
