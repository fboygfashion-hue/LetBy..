import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../../config/prisma';
import { authenticate } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { AppError } from '../../middleware/error.middleware';
import { z } from 'zod';

const submitReportSchema = z.object({
  reason:         z.enum(['SCAM', 'FAKE_LISTING', 'WRONG_PRICE', 'INAPPROPRIATE', 'OTHER']),
  description:    z.string().max(1000).optional(),
  listingId:      z.string().optional(),
  reportedUserId: z.string().optional(),
});

const router = Router();
router.use(authenticate);

// POST /api/reports — submit a scam report
router.post(
  '/',
  validate(submitReportSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { reason, description, listingId, reportedUserId } = req.body;

      if (!listingId && !reportedUserId) {
        throw new AppError('Must report either a listing or a user', 400, 'INVALID_REPORT');
      }

      const report = await prisma.report.create({
        data: {
          reporterId:     req.user!.userId,
          reason,
          description:    description ?? null,
          listingId:      listingId ?? null,
          reportedUserId: reportedUserId ?? null,
          status:         'OPEN',
        },
      });

      res.status(201).json({ success: true, data: { id: report.id, status: report.status } });
    } catch (err) { next(err); }
  },
);

export default router;
