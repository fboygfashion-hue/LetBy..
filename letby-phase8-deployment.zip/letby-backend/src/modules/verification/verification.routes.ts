import { Router } from 'express';
import { Request, Response, NextFunction } from 'express';
import multer from 'multer';
import { prisma } from '../../config/prisma';
import { uploadImage } from '../../config/cloudinary';
import { authenticate } from '../../middleware/auth.middleware';
import { AppError } from '../../middleware/error.middleware';
import { z } from 'zod';

const upload = multer({ dest: '/tmp/', limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB max

const router = Router();
router.use(authenticate);

// POST /api/verification/submit
router.post(
  '/submit',
  upload.fields([
    { name: 'nationalId', maxCount: 1 },
    { name: 'selfie',     maxCount: 1 },
  ]),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const existing = await prisma.verificationRequest.findUnique({
        where: { userId: req.user!.userId },
      });

      if (existing && existing.status === 'PENDING') {
        throw new AppError('Verification already submitted and pending review', 409, 'ALREADY_SUBMITTED');
      }
      if (existing?.status === 'APPROVED') {
        throw new AppError('Already verified', 409, 'ALREADY_VERIFIED');
      }

      const files = req.files as Record<string, Express.Multer.File[]>;
      const nationalIdFile = files['nationalId']?.[0];
      const selfieFile     = files['selfie']?.[0];

      if (!nationalIdFile) {
        throw new AppError('National ID photo is required', 400, 'MISSING_ID');
      }

      // Upload to Cloudinary — private folder (not publicly accessible)
      const { url: nationalIdUrl } = await uploadImage(nationalIdFile.path, 'verification');
      const selfieUrl = selfieFile
        ? (await uploadImage(selfieFile.path, 'verification')).url
        : null;

      const { fullName, phoneNumber } = req.body;

      // Upsert — allow resubmission after rejection
      const request = await prisma.verificationRequest.upsert({
        where:  { userId: req.user!.userId },
        create: {
          userId: req.user!.userId,
          fullName:      fullName ?? '',
          phoneNumber:   phoneNumber ?? '',
          nationalIdUrl,
          selfieUrl,
          status: 'PENDING',
        },
        update: {
          fullName:      fullName ?? '',
          phoneNumber:   phoneNumber ?? '',
          nationalIdUrl,
          selfieUrl,
          status: 'PENDING',
          reviewNote:   null,
          reviewedAt:   null,
          reviewedBy:   null,
        },
      });

      res.status(201).json({ success: true, data: { id: request.id, status: request.status } });
    } catch (err) { next(err); }
  },
);

// GET /api/verification/status
router.get('/status', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const request = await prisma.verificationRequest.findUnique({
      where: { userId: req.user!.userId },
      select: {
        id: true, status: true, reviewNote: true,
        submittedAt: true, reviewedAt: true,
      },
    });

    res.json({ success: true, data: request ?? { status: 'NOT_SUBMITTED' } });
  } catch (err) { next(err); }
});

export default router;
