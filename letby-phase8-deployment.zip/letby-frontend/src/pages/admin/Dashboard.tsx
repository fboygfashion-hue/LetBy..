import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, ShieldCheck, Package, AlertTriangle,
  TrendingUp, FileCheck, BarChart2, LogOut,
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import { Skeleton } from '@/components/ui/Skeleton';

interface Metrics {
  totalUsers: number;
  totalSellers: number;
  verifiedSellers: number;
  verificationRate: number;
  totalListings: number;
  activeListings: number;
  totalReviews: number;
  pendingVerifications: number;
  openReports: number;
  newUsersThisWeek: number;
  newListingsThisWeek: number;
}

const StatCard = ({ label, value, sub, icon: Icon, accent = false, alert = false }: any) => (
  <div className={`bg-bg-card rounded-2xl border p-4 flex items-center gap-3
    ${alert ? 'border-risk-high/40' : accent ? 'border-blue/30' : 'border-bg-border'}`}>
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0
      ${alert ? 'bg-risk-high/10' : accent ? 'bg-blue/10' : 'bg-bg-input'}`}>
      <Icon className={`w-5 h-5 ${alert ? 'text-risk-high' : accent ? 'text-blue' : 'text-ink-secondary'}`} />
    </div>
    <div className="min-w-0">
      <p className={`text-xl font-display font-bold ${alert ? 'text-risk-high' : 'text-ink'}`}>{value}</p>
      <p className="text-2xs text-ink-secondary">{label}</p>
      {sub && <p className="text-2xs text-ink-muted">{sub}</p>}
    </div>
  </div>
);

const TAB_ITEMS = [
  { id: 'overview',       label: 'Overview',       icon: BarChart2 },
  { id: 'verifications',  label: 'Verify',          icon: ShieldCheck },
  { id: 'reports',        label: 'Reports',         icon: AlertTriangle },
  { id: 'listings',       label: 'Listings',        icon: Package },
  { id: 'users',          label: 'Users',           icon: Users },
];

export const AdminDashboard = () => {
  const { user, logout } = useAuthStore();
  const navigate          = useNavigate();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab,     setTab]     = useState('overview');

  useEffect(() => {
    if (user?.role !== 'ADMIN') { navigate('/'); return; }
    api.get<{ success: boolean; data: Metrics }>('/admin/metrics')
      .then(({ data }) => setMetrics(data.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-bg">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-10 pb-4 border-b border-bg-border">
        <div>
          <p className="font-display text-lg font-bold text-ink">Admin Panel</p>
          <p className="text-2xs text-ink-muted">LetBy Platform Management</p>
        </div>
        <button onClick={() => { logout(); navigate('/'); }}
          className="w-9 h-9 rounded-xl bg-bg-input border border-bg-border flex items-center justify-center">
          <LogOut className="w-4 h-4 text-ink-secondary" />
        </button>
      </div>

      {/* Tab bar */}
      <div className="flex overflow-x-auto scrollbar-hide border-b border-bg-border px-4">
        {TAB_ITEMS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-3 text-xs font-semibold
                        border-b-2 transition-colors
              ${tab === id ? 'border-blue text-blue' : 'border-transparent text-ink-muted'}`}>
            <Icon className="w-3.5 h-3.5" />
            {label}
          </button>
        ))}
      </div>

      <div className="px-4 py-5">
        {/* OVERVIEW TAB */}
        {tab === 'overview' && (
          <div className="space-y-3">
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
            ) : metrics ? (
              <>
                <p className="text-2xs font-semibold text-ink-secondary uppercase tracking-widest mb-4">
                  Platform Stats
                </p>

                {/* Alert row — things that need action */}
                {(metrics.pendingVerifications > 0 || metrics.openReports > 0) && (
                  <div className="bg-risk-high/10 border border-risk-high/30 rounded-2xl p-4 mb-4">
                    <p className="text-sm font-bold text-risk-high mb-2">⚠️ Action Required</p>
                    <div className="flex gap-4">
                      {metrics.pendingVerifications > 0 && (
                        <button onClick={() => setTab('verifications')}
                          className="text-xs text-risk-high font-semibold">
                          {metrics.pendingVerifications} verifications pending →
                        </button>
                      )}
                      {metrics.openReports > 0 && (
                        <button onClick={() => setTab('reports')}
                          className="text-xs text-risk-high font-semibold">
                          {metrics.openReports} reports open →
                        </button>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <StatCard label="Total Users"       value={metrics.totalUsers.toLocaleString()}     icon={Users}       sub={`+${metrics.newUsersThisWeek} this week`} accent />
                  <StatCard label="Verified Sellers"  value={metrics.verifiedSellers}                 icon={ShieldCheck} sub={`${metrics.verificationRate}% of sellers`} accent />
                  <StatCard label="Active Listings"   value={metrics.activeListings.toLocaleString()} icon={Package}     sub={`+${metrics.newListingsThisWeek} this week`} />
                  <StatCard label="Total Reviews"     value={metrics.totalReviews.toLocaleString()}   icon={FileCheck}   />
                  <StatCard label="Pending Verifs"    value={metrics.pendingVerifications}             icon={ShieldCheck} alert={metrics.pendingVerifications > 0} />
                  <StatCard label="Open Reports"      value={metrics.openReports}                     icon={AlertTriangle} alert={metrics.openReports > 0} />
                </div>
              </>
            ) : (
              <p className="text-center text-ink-muted py-8">Failed to load metrics</p>
            )}
          </div>
        )}

        {/* VERIFICATIONS TAB */}
        {tab === 'verifications' && <VerificationsTab />}

        {/* REPORTS TAB */}
        {tab === 'reports' && <ReportsTab />}

        {/* LISTINGS TAB */}
        {tab === 'listings' && <ListingsTab />}

        {/* USERS TAB */}
        {tab === 'users' && <UsersTab />}
      </div>
    </div>
  );
};

// ─── SUB-TABS ────────────────────────────────────────────────────────────────

const VerificationsTab = () => {
  const [items,   setItems]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState('PENDING');

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/admin/verifications?status=${filter}&limit=30`);
      setItems(data.data.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filter]);

  const handleDecision = async (id: string, status: 'APPROVED' | 'REJECTED', note?: string) => {
    try {
      await api.put(`/admin/verifications/${id}/review`, { status, reviewNote: note });
      setItems((p) => p.filter((i) => i.id !== id));
    } catch { alert('Failed'); }
  };

  return (
    <div className="space-y-3">
      {/* Filter */}
      <div className="flex gap-2">
        {['PENDING', 'APPROVED', 'REJECTED'].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all
              ${filter === s ? 'bg-blue text-white' : 'bg-bg-card border border-bg-border text-ink-secondary'}`}>
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)
      ) : items.length === 0 ? (
        <div className="text-center py-12">
          <ShieldCheck className="w-10 h-10 text-risk-low mx-auto mb-2" />
          <p className="text-ink font-semibold">All clear</p>
          <p className="text-xs text-ink-muted">No pending verifications</p>
        </div>
      ) : (
        items.map((item) => (
          <div key={item.id} className="bg-bg-card rounded-2xl border border-bg-border p-4">
            <div className="flex items-center gap-3 mb-3">
              {item.user.photoUrl
                ? <img src={item.user.photoUrl} className="w-10 h-10 rounded-full object-cover" />
                : <div className="w-10 h-10 rounded-full bg-blue/20 flex items-center justify-center text-lg">
                    {item.user.firstName[0]}
                  </div>
              }
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-ink">
                  {item.user.firstName} {item.user.lastName}
                </p>
                {item.user.telegramUsername && (
                  <p className="text-2xs text-ink-secondary">@{item.user.telegramUsername}</p>
                )}
                {item.user.sellerProfile?.shopName && (
                  <p className="text-2xs text-etb">{item.user.sellerProfile.shopName}</p>
                )}
              </div>
              <span className={`text-2xs font-bold px-2 py-0.5 rounded-full
                ${item.status === 'PENDING'  ? 'bg-risk-medium/20 text-risk-medium' :
                  item.status === 'APPROVED' ? 'bg-risk-low/20 text-risk-low' :
                                               'bg-risk-high/20 text-risk-high'}`}>
                {item.status}
              </span>
            </div>

            {/* ID preview */}
            {item.nationalIdUrl && (
              <a href={item.nationalIdUrl} target="_blank" rel="noopener noreferrer"
                className="block mb-3">
                <img src={item.nationalIdUrl} className="w-full h-24 object-cover rounded-xl" />
              </a>
            )}

            <div className="text-xs text-ink-secondary mb-3">
              <span>📞 {item.phoneNumber}</span>
              <span className="ml-3">
                Submitted: {new Date(item.submittedAt).toLocaleDateString()}
              </span>
            </div>

            {item.status === 'PENDING' && (
              <div className="flex gap-2">
                <button onClick={() => handleDecision(item.id, 'APPROVED')}
                  className="flex-1 py-2.5 rounded-xl bg-risk-low/20 text-risk-low text-sm font-bold
                             border border-risk-low/30 hover:bg-risk-low/30 transition-colors">
                  ✓ Approve
                </button>
                <button onClick={() => {
                    const note = prompt('Rejection reason:');
                    if (note !== null) handleDecision(item.id, 'REJECTED', note);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-risk-high/10 text-risk-high text-sm font-bold
                             border border-risk-high/30 hover:bg-risk-high/20 transition-colors">
                  ✗ Reject
                </button>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

const ReportsTab = () => {
  const [items,   setItems]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState('OPEN');

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/admin/reports?status=${filter}&limit=30`);
      setItems(data.data.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filter]);

  const resolve = async (id: string, status: 'RESOLVED' | 'DISMISSED', banSeller = false) => {
    try {
      const note = status === 'RESOLVED' ? prompt('Resolution note:') ?? '' : '';
      await api.put(`/admin/reports/${id}/resolve`, { status, resolvedNote: note, banSeller });
      setItems((p) => p.filter((i) => i.id !== id));
    } catch { alert('Failed'); }
  };

  const REASON_COLORS: Record<string, string> = {
    SCAM:        'text-risk-high bg-risk-high/10',
    FAKE_LISTING:'text-risk-medium bg-risk-medium/10',
    WRONG_PRICE: 'text-risk-medium bg-risk-medium/10',
    INAPPROPRIATE:'text-ink-secondary bg-bg-input',
    OTHER:       'text-ink-muted bg-bg-input',
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {['OPEN', 'RESOLVED', 'DISMISSED'].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all
              ${filter === s ? 'bg-blue text-white' : 'bg-bg-card border border-bg-border text-ink-secondary'}`}>
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)
      ) : items.length === 0 ? (
        <div className="text-center py-12">
          <AlertTriangle className="w-10 h-10 text-risk-low mx-auto mb-2" />
          <p className="text-ink font-semibold">No {filter.toLowerCase()} reports</p>
        </div>
      ) : (
        items.map((item) => (
          <div key={item.id} className="bg-bg-card rounded-2xl border border-bg-border p-4 space-y-3">
            {/* Header */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <span className={`inline-block text-2xs font-bold px-2 py-0.5 rounded-full mb-1 ${REASON_COLORS[item.reason] ?? 'text-ink-muted'}`}>
                  {item.reason.replace('_', ' ')}
                </span>
                {item.listing && (
                  <p className="text-sm font-semibold text-ink line-clamp-1">{item.listing.title}</p>
                )}
                {item.reportedUser && (
                  <p className="text-xs text-ink-secondary">
                    Seller: {item.reportedUser.firstName}
                    {item.reportedUser.sellerProfile?.scamReports > 0 && (
                      <span className="text-risk-high ml-1">
                        • {item.reportedUser.sellerProfile.scamReports} prior reports
                      </span>
                    )}
                  </p>
                )}
              </div>
              <span className={`text-2xs font-bold px-2 py-0.5 rounded-full flex-shrink-0
                ${item.status === 'OPEN' ? 'bg-risk-high/20 text-risk-high' :
                  item.status === 'RESOLVED' ? 'bg-risk-low/20 text-risk-low' :
                                               'bg-bg-input text-ink-muted'}`}>
                {item.status}
              </span>
            </div>

            {item.description && (
              <p className="text-xs text-ink-secondary italic">"{item.description}"</p>
            )}

            <p className="text-2xs text-ink-muted">
              Reported by: {item.reporter.firstName}
              {item.reporter.telegramUsername && ` (@${item.reporter.telegramUsername})`} •{' '}
              {new Date(item.createdAt).toLocaleDateString()}
            </p>

            {item.status === 'OPEN' && (
              <div className="flex gap-2 flex-wrap">
                <button onClick={() => resolve(item.id, 'RESOLVED', false)}
                  className="flex-1 py-2 rounded-xl bg-risk-low/10 text-risk-low text-xs font-bold
                             border border-risk-low/30">
                  ✓ Resolve
                </button>
                <button onClick={() => resolve(item.id, 'RESOLVED', true)}
                  className="flex-1 py-2 rounded-xl bg-risk-high/10 text-risk-high text-xs font-bold
                             border border-risk-high/30">
                  🚫 Resolve + Ban
                </button>
                <button onClick={() => resolve(item.id, 'DISMISSED')}
                  className="flex-1 py-2 rounded-xl bg-bg-input text-ink-secondary text-xs font-bold
                             border border-bg-border">
                  Dismiss
                </button>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

const ListingsTab = () => {
  const [items,   setItems]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState('ACTIVE');

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/admin/listings?status=${filter}&limit=30`);
      setItems(data.data.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filter]);

  const remove = async (id: string) => {
    const reason = prompt('Removal reason:');
    if (!reason) return;
    try {
      await api.delete(`/admin/listings/${id}`, { data: { reason } });
      setItems((p) => p.filter((i) => i.id !== id));
    } catch { alert('Failed'); }
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
        {['ACTIVE', 'REMOVED', 'SOLD', 'PAUSED'].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all
              ${filter === s ? 'bg-blue text-white' : 'bg-bg-card border border-bg-border text-ink-secondary'}`}>
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
      ) : items.map((item) => (
        <div key={item.id}
          className="flex items-center gap-3 bg-bg-card rounded-xl p-3 border border-bg-border">
          {/* Thumbnail */}
          <div className="w-14 h-14 rounded-xl bg-bg-input flex-shrink-0 overflow-hidden">
            {item.images[0]?.url
              ? <img src={item.images[0].url} className="w-full h-full object-cover" />
              : <div className="w-full h-full flex items-center justify-center text-xl">📦</div>
            }
          </div>
          {/* Details */}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-ink line-clamp-1">{item.title}</p>
            <p className="text-xs text-etb font-bold">{(item.price / 100).toLocaleString()} ETB</p>
            <p className="text-2xs text-ink-secondary">
              {item.seller.firstName}
              {item.seller.sellerProfile?.isVerified && ' ✓'}
              {' • '}{item._count.reports > 0 && (
                <span className="text-risk-high">{item._count.reports} reports</span>
              )}
            </p>
          </div>
          {filter === 'ACTIVE' && (
            <button onClick={() => remove(item.id)}
              className="px-3 py-1.5 rounded-lg bg-risk-high/10 text-risk-high text-xs font-bold
                         border border-risk-high/30 flex-shrink-0">
              Remove
            </button>
          )}
        </div>
      ))}
    </div>
  );
};

const UsersTab = () => {
  const [items,   setItems]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/users?limit=30')
      .then(({ data }) => setItems(data.data.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-2.5">
      {loading ? (
        Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
      ) : items.map((user) => (
        <div key={user.id}
          className={`flex items-center gap-3 bg-bg-card rounded-xl p-3 border
            ${!user.isActive ? 'border-risk-high/30 opacity-60' : 'border-bg-border'}`}>
          <div className="w-9 h-9 rounded-full bg-blue/20 flex items-center justify-center text-base flex-shrink-0">
            {user.firstName[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-ink">
              {user.firstName} {user.lastName}
              {!user.isActive && <span className="text-risk-high text-2xs ml-1">BANNED</span>}
            </p>
            <p className="text-2xs text-ink-secondary">
              {user.telegramUsername && `@${user.telegramUsername} • `}
              {user.role}
              {user.sellerProfile?.isVerified && ' ✓'}
            </p>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-xs font-bold text-ink">{user._count.listings}</p>
            <p className="text-2xs text-ink-muted">listings</p>
          </div>
        </div>
      ))}
    </div>
  );
};
